package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;

@Entity
public class Rent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tenantName;
    private String tenantPhoneNumber;
    private String rentAddress;
    private String rentDescription;

    @Lob
    @Column(name = "rent_image", columnDefinition = "MEDIUMBLOB")
    private String rentImage; // Store image as text (base64 encoded or file path)

    @Lob
    @Column(name = "rent_documents", columnDefinition = "MEDIUMBLOB")
    private String rentDocuments; // Store documents as text (base64 encoded or file path)

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getTenantPhoneNumber() {
        return tenantPhoneNumber;
    }

    public void setTenantPhoneNumber(String tenantPhoneNumber) {
        this.tenantPhoneNumber = tenantPhoneNumber;
    }

    public String getRentAddress() {
        return rentAddress;
    }

    public void setRentAddress(String rentAddress) {
        this.rentAddress = rentAddress;
    }

    public String getRentDescription() {
        return rentDescription;
    }

    public void setRentDescription(String rentDescription) {
        this.rentDescription = rentDescription;
    }

    public String getRentImage() {
        return rentImage;
    }

    public void setRentImage(String rentImage) {
        this.rentImage = rentImage;
    }

    public String getRentDocuments() {
        return rentDocuments;
    }

    public void setRentDocuments(String rentDocuments) {
        this.rentDocuments = rentDocuments;
    }
}
