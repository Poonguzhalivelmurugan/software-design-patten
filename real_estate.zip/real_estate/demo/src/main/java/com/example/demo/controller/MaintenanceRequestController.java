package com.example.demo.controller;

import com.example.demo.model.MaintenanceRequest;
import com.example.demo.service.MaintenanceRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/maintenance-requests")
public class MaintenanceRequestController {

    @Autowired
    private MaintenanceRequestService maintenanceRequestService;

    @PostMapping
    public ResponseEntity<MaintenanceRequest> createMaintenanceRequest(@RequestBody MaintenanceRequest request) {
        MaintenanceRequest createdRequest = maintenanceRequestService.createMaintenanceRequest(request);
        return ResponseEntity.ok(createdRequest);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MaintenanceRequest> getMaintenanceRequestById(@PathVariable Long id) {
        MaintenanceRequest request = maintenanceRequestService.getMaintenanceRequestById(id);
        if (request != null) {
            return ResponseEntity.ok(request);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<MaintenanceRequest>> getAllMaintenanceRequests() {
        List<MaintenanceRequest> requests = maintenanceRequestService.getAllMaintenanceRequests();
        return ResponseEntity.ok(requests);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MaintenanceRequest> updateMaintenanceRequest(@PathVariable Long id, @RequestBody MaintenanceRequest request) {
        MaintenanceRequest updatedRequest = maintenanceRequestService.updateMaintenanceRequest(id, request);
        if (updatedRequest != null) {
            return ResponseEntity.ok(updatedRequest);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMaintenanceRequest(@PathVariable Long id) {
        if (maintenanceRequestService.deleteMaintenanceRequest(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.ModelAttribute;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestPart;
// import org.springframework.web.bind.annotation.RestController;
// import org.springframework.web.multipart.MultipartFile;

// import com.example.demo.model.MaintenanceRequest;
// import com.example.demo.service.MaintenanceRequestService;

// @RestController
// @RequestMapping("/api/maintenance")
// public class MaintenanceRequestController {

//     @Autowired
//     private MaintenanceRequestService service;

//     @PostMapping
//     public ResponseEntity<String> createMaintenanceRequest(
//             @RequestPart("issueDescription") String issueDescription,
//             @RequestPart("priority") String priority,
//             @RequestPart("category") String category,
//             @RequestPart("propertyAddress") String propertyAddress,
//             @RequestPart("unitNumber") String unitNumber,
//             @RequestPart("contactName") String contactName,
//             @RequestPart("phoneNumber") String phoneNumber,
//             @RequestPart("email") String email,
//             @RequestPart("images") MultipartFile[] images,
//             @RequestPart("documents") MultipartFile[] documents) {

//         try {
//             // Create a MaintenanceRequest instance and set its fields
//             MaintenanceRequest request = new MaintenanceRequest();
//             request.setIssueDescription(issueDescription);
//             request.setPriority(priority);
//             request.setCategory(category);
//             request.setPropertyAddress(propertyAddress);
//             request.setUnitNumber(unitNumber);
//             request.setContactName(contactName);
//             request.setPhoneNumber(phoneNumber);
//             request.setEmail(email);
//             // Handle images and documents as needed
//             // e.g., save them to a file system or database

//             // Save the MaintenanceRequest
//             service.saveMaintenanceRequest(request);
//             return new ResponseEntity<>("Maintenance request submitted successfully!", HttpStatus.CREATED);
//         } catch (Exception e) {
//             return new ResponseEntity<>("Failed to submit maintenance request.", HttpStatus.INTERNAL_SERVER_ERROR);
//         }
//     }

//     @GetMapping("/{id}")
//     public ResponseEntity<MaintenanceRequest> getMaintenanceRequest(@PathVariable Long id) {
//         Optional<MaintenanceRequest> request = service.getMaintenanceRequest(id);
//         return request.map(ResponseEntity::ok)
//                       .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
//     }
// }

