package com.example.demo.controller;

import com.example.demo.model.Buy;
import com.example.demo.service.BuyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/buys")
public class BuyController {

    @Autowired
    private BuyService buyService;

    // Endpoint to create a new Buy entry
    @PostMapping
    public ResponseEntity<Buy> createBuy(@RequestBody Buy buy) {
        try {
            Buy savedBuy = buyService.saveBuy(buy);
            return new ResponseEntity<>(savedBuy, HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception (Consider using a logger in real applications)
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Endpoint to get a Buy entry by ID
    @GetMapping("/{id}")
    public ResponseEntity<Buy> getBuyById(@PathVariable("id") Long id) {
        try {
            Buy buy = buyService.getBuyById(id);
            if (buy != null) {
                return new ResponseEntity<>(buy, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception (Consider using a logger in real applications)
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Optional: Endpoint to update an existing Buy entry
    @PutMapping("/{id}")
    public ResponseEntity<Buy> updateBuy(@PathVariable("id") Long id, @RequestBody Buy buy) {
        try {
            Buy updatedBuy = buyService.updateBuy(id, buy);
            if (updatedBuy != null) {
                return new ResponseEntity<>(updatedBuy, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception (Consider using a logger in real applications)
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Optional: Endpoint to delete a Buy entry
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteBuy(@PathVariable("id") Long id) {
        try {
            boolean isRemoved = buyService.deleteBuy(id);
            if (isRemoved) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception (Consider using a logger in real applications)
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
