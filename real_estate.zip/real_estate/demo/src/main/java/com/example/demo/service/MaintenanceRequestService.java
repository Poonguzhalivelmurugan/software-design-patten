package com.example.demo.service;

import com.example.demo.model.MaintenanceRequest;
import com.example.demo.repository.MaintenanceRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MaintenanceRequestService {

    @Autowired
    private MaintenanceRequestRepository maintenanceRequestRepository;

    public MaintenanceRequest createMaintenanceRequest(MaintenanceRequest request) {
        return maintenanceRequestRepository.save(request);
    }

    public MaintenanceRequest getMaintenanceRequestById(Long id) {
        Optional<MaintenanceRequest> request = maintenanceRequestRepository.findById(id);
        return request.orElse(null);
    }

    public List<MaintenanceRequest> getAllMaintenanceRequests() {
        return maintenanceRequestRepository.findAll();
    }

    public MaintenanceRequest updateMaintenanceRequest(Long id, MaintenanceRequest request) {
        if (maintenanceRequestRepository.existsById(id)) {
            request.setId(id);
            return maintenanceRequestRepository.save(request);
        } else {
            return null;
        }
    }

    public boolean deleteMaintenanceRequest(Long id) {
        if (maintenanceRequestRepository.existsById(id)) {
            maintenanceRequestRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}


// import com.example.demo.model.MaintenanceRequest;
// import com.example.demo.repository.MaintenanceRequestRepository;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// import java.util.Optional;

// @Service
// public class MaintenanceRequestService {

//     @Autowired
//     private MaintenanceRequestRepository repository;

//     public MaintenanceRequest saveMaintenanceRequest(MaintenanceRequest request) {
//         return repository.save(request);
//     }

//     public Optional<MaintenanceRequest> getMaintenanceRequest(Long id) {
//         return repository.findById(id);
//     }
// }
