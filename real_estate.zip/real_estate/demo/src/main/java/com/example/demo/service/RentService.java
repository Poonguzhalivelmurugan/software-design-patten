package com.example.demo.service;

import com.example.demo.model.Rent;
import com.example.demo.repository.RentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RentService {

    @Autowired
    private RentRepository rentRepository;

    public void saveRent(Rent rent) {
        rentRepository.save(rent);
    }

    public Rent getRentById(Long id) {
        return rentRepository.findById(id).orElse(null);
    }

    public void updateRent(Long id, Rent rent) {
        if (rentRepository.existsById(id)) {
            rent.setId(id);
            rentRepository.save(rent);
        }
    }

    public void deleteRent(Long id) {
        rentRepository.deleteById(id);
    }
}
