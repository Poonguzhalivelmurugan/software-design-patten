package com.example.demo.service;

import com.example.demo.model.Buy;
import com.example.demo.repository.BuyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BuyService {

    @Autowired
    private BuyRepository buyRepository;

    // Method to save a new Buy entry
    public Buy saveBuy(Buy buy) {
        return buyRepository.save(buy);
    }

    // Method to get a Buy entry by ID
    public Buy getBuyById(Long id) {
        Optional<Buy> optionalBuy = buyRepository.findById(id);
        return optionalBuy.orElse(null);
    }

    // Method to update an existing Buy entry
    public Buy updateBuy(Long id, Buy buy) {
        if (buyRepository.existsById(id)) {
            buy.setId(id); // Ensure the ID is set for the update operation
            return buyRepository.save(buy);
        }
        return null; // Return null if the entry does not exist
    }

    // Method to delete a Buy entry by ID
    public boolean deleteBuy(Long id) {
        if (buyRepository.existsById(id)) {
            buyRepository.deleteById(id);
            return true;
        }
        return false; // Return false if the entry does not exist
    }
}
