

package com.example.demo.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtils {

    public static byte[] readFileToByteArray(String filePath) throws IOException {
        return Files.readAllBytes(Paths.get(filePath));
    }

    public static void writeByteArrayToFile(byte[] data, String filePath) throws IOException {
        Files.write(Paths.get(filePath), data);
    }
}
