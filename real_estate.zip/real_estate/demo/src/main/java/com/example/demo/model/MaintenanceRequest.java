package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Column;

@Entity
public class MaintenanceRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String issueDescription;
    private String priority;
    private String category;
    private String propertyAddress;
    private String unitNumber;
    private String contactName;
    private String phoneNumber;
    private String email;
    
    @Lob
    @Column(columnDefinition = "MEDIUMBLOB")
    private String imageBase64; // Base64-encoded image data
    
    @Lob
    @Column(columnDefinition = "MEDIUMBLOB")
    private String documentBase64; // Base64-encoded document data

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public void setPropertyAddress(String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public void setImageBase64(String imageBase64) {
        this.imageBase64 = imageBase64;
    }

    public String getDocumentBase64() {
        return documentBase64;
    }

    public void setDocumentBase64(String documentBase64) {
        this.documentBase64 = documentBase64;
    }
}

// import java.util.List;

// import jakarta.persistence.ElementCollection;
// import jakarta.persistence.Entity;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;

// @Entity
// public class MaintenanceRequest {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     private String propertyAddress;
//     private String unitNumber;
//     private String issueDescription;
//     private String priority;
//     private String category;
//     private String contactName;
//     private String phoneNumber;
//     private String email;

//     @ElementCollection
//     private List<String> images;

//     @ElementCollection
//     private List<String> documents;

//     // Getters and Setters

//     public Long getId() {
//         return id;
//     }

//     public void setId(Long id) {
//         this.id = id;
//     }

//     public String getPropertyAddress() {
//         return propertyAddress;
//     }

//     public void setPropertyAddress(String propertyAddress) {
//         this.propertyAddress = propertyAddress;
//     }

//     public String getUnitNumber() {
//         return unitNumber;
//     }

//     public void setUnitNumber(String unitNumber) {
//         this.unitNumber = unitNumber;
//     }

//     public String getIssueDescription() {
//         return issueDescription;
//     }

//     public void setIssueDescription(String issueDescription) {
//         this.issueDescription = issueDescription;
//     }

//     public String getPriority() {
//         return priority;
//     }

//     public void setPriority(String priority) {
//         this.priority = priority;
//     }

//     public String getCategory() {
//         return category;
//     }

//     public void setCategory(String category) {
//         this.category = category;
//     }

//     public String getContactName() {
//         return contactName;
//     }

//     public void setContactName(String contactName) {
//         this.contactName = contactName;
//     }

//     public String getPhoneNumber() {
//         return phoneNumber;
//     }

//     public void setPhoneNumber(String phoneNumber) {
//         this.phoneNumber = phoneNumber;
//     }

//     public String getEmail() {
//         return email;
//     }

//     public void setEmail(String email) {
//         this.email = email;
//     }

//     public List<String> getImages() {
//         return images;
//     }

//     public void setImages(List<String> images) {
//         this.images = images;
//     }

//     public List<String> getDocuments() {
//         return documents;
//     }

//     public void setDocuments(List<String> documents) {
//         this.documents = documents;
//     }
// }
