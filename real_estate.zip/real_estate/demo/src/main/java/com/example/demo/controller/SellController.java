package com.example.demo.controller;

import com.example.demo.model.Sell;
import com.example.demo.service.SellService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/sell")
public class SellController {

    @Autowired
    private SellService sellService;

    @PostMapping
    public ResponseEntity<String> createSell(@RequestBody Sell sell) {
        try {
            sellService.saveSell(sell);
            return new ResponseEntity<>("Sell details submitted successfully!", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to submit sell details.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/all")
public ResponseEntity<List<Sell>> getAllSells() {
    List<Sell> sells = sellService.getAllSells();
    return new ResponseEntity<>(sells, HttpStatus.OK);
}

    @GetMapping("/{id}")
    public ResponseEntity<Sell> getSellById(@PathVariable Long id) {
        Sell sell = sellService.getSellById(id);
        if (sell != null) {
            return new ResponseEntity<>(sell, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateSell(@PathVariable Long id, @RequestBody Sell sell) {
        try {
            sellService.updateSell(id, sell);
            return new ResponseEntity<>("Sell details updated successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to update sell details.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSell(@PathVariable Long id) {
        try {
            sellService.deleteSell(id);
            return new ResponseEntity<>("Sell details deleted successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete sell details.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
