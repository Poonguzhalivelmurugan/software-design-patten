package com.example.demo.controller;

import com.example.demo.model.Rent;
import com.example.demo.service.RentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rent")
public class RentController {

    @Autowired
    private RentService rentService;

    @PostMapping
    public ResponseEntity<String> createRent(@RequestBody Rent rent) {
        try {
            rentService.saveRent(rent);
            return new ResponseEntity<>("Rent details submitted successfully!", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to submit rent details.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Rent> getRentById(@PathVariable Long id) {
        Rent rent = rentService.getRentById(id);
        if (rent != null) {
            return new ResponseEntity<>(rent, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateRent(@PathVariable Long id, @RequestBody Rent rent) {
        try {
            rentService.updateRent(id, rent);
            return new ResponseEntity<>("Rent details updated successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to update rent details.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRent(@PathVariable Long id) {
        try {
            rentService.deleteRent(id);
            return new ResponseEntity<>("Rent details deleted successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to delete rent details.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
