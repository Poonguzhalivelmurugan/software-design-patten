// package com.example.demo.controller;

// import com.example.demo.model.User;
// import com.example.demo.service.UserService;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
// import org.springframework.web.bind.annotation.*;

// import java.util.List;
// import java.util.Optional;

// @RestController
// @RequestMapping("/users")
// public class UserController {

//     @Autowired
//     private UserService userService;

//     // Retrieve all users - accessible by anyone
//     @GetMapping
//     @PreAuthorize("permitAll()")
//     public ResponseEntity<List<User>> getAllUsers() {
//         List<User> users = userService.getAllUsers();
//         return new ResponseEntity<>(users, HttpStatus.OK);
//     }

//     // Retrieve a user by ID - accessible by admins and the user themselves
//     @GetMapping("/{id}")
//     @PreAuthorize("hasRole('ROLE_ADMIN') or @userSecurityService.isCurrentUserId(#id)")
//     public ResponseEntity<User> getUserById(@PathVariable("id") Long id) {
//         Optional<User> user = userService.getUserById(id);
//         return user.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
//                 .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
//     }

//     // Create a new user - accessible by anyone
//     @PostMapping
//     @PreAuthorize("permitAll()")
//     public ResponseEntity<User> createUser(@RequestBody User user) {
//         User createdUser = userService.saveUser(user);
//         return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
//     }

//     // Update an existing user - accessible by admins only
//     @PutMapping("/{id}")
//     @PreAuthorize("hasRole('ROLE_ADMIN')")
//     public ResponseEntity<User> updateUser(@PathVariable("id") Long id, @RequestBody User user) {
//         User updatedUser = userService.updateUser(id, user);
//         return updatedUser != null ? 
//             new ResponseEntity<>(updatedUser, HttpStatus.OK) : 
//             new ResponseEntity<>(HttpStatus.NOT_FOUND);
//     }

//     // Delete a user by ID - accessible by admins only
//     @DeleteMapping("/{id}")
//     @PreAuthorize("hasRole('ROLE_ADMIN')")
//     public ResponseEntity<Void> deleteUser(@PathVariable("id") Long id) {
//         userService.deleteUser(id);
//         return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//     }
// }

package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.saveUser(user);
        return ResponseEntity.ok(createdUser);
    }
      @GetMapping("/current")
    public ResponseEntity<Optional<User>> getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated() && !authentication.getName().equals("anonymousUser")) {
            Optional<User> user = userService.getUserByEmail(authentication.getName());
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
        User updatedUser = userService.updateUser(id, user);
        if (updatedUser != null) {
            return ResponseEntity.ok(updatedUser);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<Optional<User>> getUserByEmail(@PathVariable String email) {
        Optional<User> user = userService.getUserByEmail(email);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}
