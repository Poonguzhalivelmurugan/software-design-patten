import { faBath, faBed, faCar, faRuler } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState } from 'react';
import './propertyinfo.css';

const PropertyInfo = () => {
  const [reviews, setReviews] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', comments: '' });
  const [requestForm, setRequestForm] = useState({ name: '', email: '', phone: '', interest: '' });
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const images = [
    "https://dreamsestate.dreamstechnologies.com/html/assets/img/rent/rent-detail-02.jpg",
    "https://dreamsestate.dreamstechnologies.com/html/assets/img/rent/rent-detail-05.jpg",
    "https://dreamsestate.dreamstechnologies.com/html/assets/img/rent/rent-detail-03.jpg",
    "https://dreamsestate.dreamstechnologies.com/html/assets/img/rent/rent-detail-04.jpg",
    "https://dreamsestate.dreamstechnologies.com/html/assets/img/rent/rent-detail-05.jpg"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [images.length]);

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    setReviews([...reviews, form]);
    setForm({ name: '', email: '', comments: '' });
  };

  const handleRequestSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8080/buys', { // Replace with your backend URL
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestForm)
      });
      if (response.ok) {
        // Handle successful submission (e.g., show a confirmation message)
        setRequestForm({ name: '', email: '', phone: '', interest: '' });
        alert('Request submitted successfully!');
      } else {
        // Handle errors
        alert('Failed to submit request.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred while submitting the request.');
    }
  };

  const handleShareClick = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Check out this property!',
        url: window.location.href,
      })
      .then(() => console.log('Thanks for sharing!'))
      .catch((error) => console.log('Error sharing:', error));
    } else {
      alert('Share not supported on this browser.');
    }
  };

  const handleEmailClick = () => window.location.href = 'mailto:info@example.com';
  const handleCallClick = () => window.location.href = 'tel:+1234567890';
  const handleWhatsappClick = () => window.location.href = 'https://wa.me/1234567890'; // Replace with actual number

  const containerStyle = {
    width: '100%',
    height: '400px'
  };

  const center = {
    lat: -1.2884, // Replace with the property's latitude
    lng: 36.8233  // Replace with the property's longitude
  };

  return (
    <div className="property-detail-view">
      <div className="property-detail-view-overview">
        <div className="property-slider">
          <div className="slider-container">
            {images.map((image, index) => (
              <div
                key={index}
                className={`slider-image ${index === currentImageIndex ? 'active' : ''}`}
                style={{ backgroundImage: `url(${image})` }}
              ></div>
            ))}
          </div>
        </div>
        <div className="property-detail-view-info">
          <h2>Property Overview</h2>
          <div className="property-details">
            <div className="detail-item">
              <FontAwesomeIcon icon={faBed} className="detail-icon" />
              <p><strong>4 Beds</strong></p>
            </div>
            <div className="detail-item">
              <FontAwesomeIcon icon={faBath} className="detail-icon" />
              <p><strong>4 Baths</strong></p>
            </div>
            <div className="detail-item">
              <FontAwesomeIcon icon={faRuler} className="detail-icon" />
              <p><strong>35,000 Sqft</strong></p>
            </div>
            <div className="detail-item">
              <FontAwesomeIcon icon={faCar} className="detail-icon" />
              <p><strong>2 Garages</strong></p>
            </div>
            <p><strong>Year Built:</strong> 2005</p>
          </div>
          <button className="property-detail-view-share-button" onClick={handleShareClick}>Share</button>
        </div>
      </div>

      <div className="property-detail-view-request-info">
        <h3>Request Info</h3>
        <form onSubmit={handleRequestSubmit}>
          <label>Full Name:
            <input
              type="text"
              value={requestForm.name}
              onChange={(e) => setRequestForm({ ...requestForm, name: e.target.value })}
              required
            />
          </label>
          <label>Email Address:
            <input
              type="email"
              value={requestForm.email}
              onChange={(e) => setRequestForm({ ...requestForm, email: e.target.value })}
              required
            />
          </label>
          <label>Mobile Number:
            <input
              type="tel"
              value={requestForm.phone}
              onChange={(e) => setRequestForm({ ...requestForm, phone: e.target.value })}
              required
            />
          </label>
          <label>Yes, I'm Interested:
            <input
              type="text"
              value={requestForm.interest}
              onChange={(e) => setRequestForm({ ...requestForm, interest: e.target.value })}
              required
            />
          </label>
          <button type="submit">Request Callback</button>
        </form>
        <div className="property-detail-view-contact-options">
          <button onClick={handleEmailClick}>Email Us</button>
          <button onClick={handleCallClick}>Call Us</button>
          <button onClick={handleWhatsappClick}>Whatsapp</button>
        </div>
      </div>

      {/* <div className="property-detail-view-map">
        <LoadScript
          googleMapsApiKey="YOUR_GOOGLE_MAPS_API_KEY" // Replace with your Google Maps API key
        >
          <GoogleMap
            mapContainerStyle={containerStyle}
            center={center}
            zoom={14}
          >
            <Marker position={center} />
          </GoogleMap>
        </LoadScript>
      </div> */}

      <div className="property-detail-view-location">
        <h2>Our Location</h2>
        <iframe
          title="Our Location"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.953613939483!2d79.13782741462207!3d10.790483792316394!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5525a1f5d0c6b1%3A0x2f0e62e07367a5f2!2sTamil%20Nadu%2C%20India!5e0!3m2!1sen!2sus!4v1628850941730!5m2!1sen!2sus"
          style={containerStyle}
          allowFullScreen
          loading="lazy"
        ></iframe>
      </div>
    </div>
  );
};

export default PropertyInfo;
