import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './admin.css';

function AdminPage() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isUserDropdownOpen, setUserDropdownOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [properties, setProperties] = useState([]);
  const [newUser, setNewUser] = useState({ name: '', email: '', mobile: '', password: '', confirmPassword: '', roles: '' });
  const [editUser, setEditUser] = useState(null); // State to manage the user being edited
  const [showForm, setShowForm] = useState(false); // State to manage form visibility
  const [showEditForm, setShowEditForm] = useState(false); // State to manage edit form visibility
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [showMessage, setShowMessage] = useState('');

  useEffect(() => {
    fetchUsers();
    fetchProperties();
  }, []);

  const fetchUsers = () => {
    axios.get('http://localhost:8080/api/users/all')
      .then(response => {
        setUsers(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the users!', error);
        setError('There was an error fetching the users.');
      });
  };

  const fetchProperties = () => {
    axios.get('http://localhost:8080/api/sell/all')
      .then(response => {
        setProperties(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the properties!', error);
        setError('There was an error fetching the properties.');
      });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewUser(prevState => ({ ...prevState, [name]: value }));
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditUser(prevState => ({ ...prevState, [name]: value }));
  };

  const addUser = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/api/users', newUser)
      .then(response => {
        setUsers([...users, response.data]);
        setNewUser({ name: '', email: '', mobile: '', password: '', confirmPassword: '', roles: '' });
        setError(null);
        setSuccess('User added successfully.');
        setShowMessage('User added successfully!');
        setTimeout(() => setShowMessage(''), 3000);
      })
      .catch(error => {
        console.error('There was an error adding the user!', error);
        setError('There was an error adding the user.');
        setSuccess(null);
      });
  };

  const updateUser = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:8080/api/users/${editUser.id}`, editUser)
      .then(response => {
        const updatedUsers = users.map(user => user.id === editUser.id ? response.data : user);
        setUsers(updatedUsers);
        setEditUser(null);
        setShowEditForm(false);
        setError(null);
        setSuccess('User updated successfully.');
        setShowMessage('User updated successfully!');
        setTimeout(() => setShowMessage(''), 3000);
      })
      .catch(error => {
        console.error('There was an error updating the user!', error);
        setError('There was an error updating the user.');
        setSuccess(null);
      });
  };

  const deleteUser = (id) => {
    axios.delete(`http://localhost:8080/api/users/${id}`)
      .then(() => {
        setUsers(users.filter(user => user.id !== id));
        setError(null);
        setSuccess('User deleted successfully.');
        setShowMessage('User deleted successfully!');
        setTimeout(() => setShowMessage(''), 3000);
      })
      .catch(error => {
        console.error('There was an error deleting the user!', error);
        setError('There was an error deleting the user.');
        setSuccess(null);
      });
  };

  const deleteProperty = (id) => {
    axios.delete(`http://localhost:8080/api/sell/${id}`)
      .then(() => {
        setProperties(properties.filter(property => property.id !== id));
        setError(null);
        setSuccess('Property deleted successfully.');
        setShowMessage('Property deleted successfully!');
        setTimeout(() => setShowMessage(''), 3000);
      })
      .catch(error => {
        console.error('There was an error deleting the property!', error);
        setError('There was an error deleting the property.');
        setSuccess(null);
      });
  };

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const toggleUserDropdown = () => {
    setUserDropdownOpen(!isUserDropdownOpen);
  };

  return (
    <div className="dashboard-container">
      <header className="header-bar">
        <i className="fas fa-bars menu-icon" onClick={toggleSidebar}></i>
        <h1>Welcome Back, <span>🎉</span></h1>
        <div className="header-actions">
          <input type="text" placeholder="Search" />
          <i className="fas fa-bell" onClick={() => { /* Show notifications dropdown */ }}></i>
          <i className="fas fa-user" onClick={toggleUserDropdown}></i>
          {isUserDropdownOpen && (
            <div className="dropdown-menu">
              <div className="user-details">
                <p>John Doe</p>
                <p>johndoe@example.com</p>
              </div>
              <a href="/profile" className="dropdown-item">Profile</a>
              <a href="/logout" className="dropdown-item">Logout</a>
            </div>
          )}
        </div>
      </header>

      <aside className={`side-menu ${isSidebarOpen ? 'open' : ''}`}>
        <div className="side-menu-header">
          <h2>Dashboard</h2>
          <i className="fas fa-times" onClick={toggleSidebar}></i>
        </div>
        <nav className="side-menu-nav">
          <ul>
            <li><i className="fas fa-home"></i> Home</li>
            <li><i className="fas fa-users"></i> Users</li>
            <li><i className="fas fa-building"></i> Properties</li>
            <li><i className="fas fa-cogs"></i> Settings</li>
          </ul>
        </nav>
        <div className="side-menu-footer">
          <div className="user-info">
            <p>John Doe</p>
            <p>johndoe@example.com</p>
          </div>
        </div>
      </aside>

      <div className="content-area">
        <button className="add-user-btn" onClick={() => setShowForm(!showForm)}>Add New User</button>

        {showForm && (
          <div className="form-wrapper">
            <h2>Add New User</h2>
            {error && <div className="error-notification">{error}</div>}
            {success && <div className="success-notification">{success}</div>}
            <form className="add-user-form" onSubmit={addUser}>
              <label>Name</label>
              <input type="text" name="name" value={newUser.name} onChange={handleChange} required />
              
              <label>Email</label>
              <input type="email" name="email" value={newUser.email} onChange={handleChange} required />
              
              <label>Mobile</label>
              <input type="text" name="mobile" value={newUser.mobile} onChange={handleChange} required />
              
              <label>Password</label>
              <input type="password" name="password" value={newUser.password} onChange={handleChange} required />
              
              <label>Confirm Password</label>
              <input type="password" name="confirmPassword" value={newUser.confirmPassword} onChange={handleChange} required />
              
              <label>Roles</label>
              <input type="text" name="roles" value={newUser.roles} onChange={handleChange} required />
              
              <button type="submit">Add User</button>
            </form>
          </div>
        )}

        {showEditForm && editUser && (
          <div className="form-wrapper">
            <h2>Edit User</h2>
            {error && <div className="error-notification">{error}</div>}
            {success && <div className="success-notification">{success}</div>}
            <form className="add-user-form" onSubmit={updateUser}>
              <label>Name</label>
              <input type="text" name="name" value={editUser.name} onChange={handleEditChange} required />
              
              <label>Email</label>
              <input type="email" name="email" value={editUser.email} onChange={handleEditChange} required />
              
              <label>Mobile</label>
              <input type="text" name="mobile" value={editUser.mobile} onChange={handleEditChange} required />
              
              <label>Password</label>
              <input type="password" name="password" value={editUser.password} onChange={handleEditChange} required />
              
              <label>Confirm Password</label>
              <input type="password" name="confirmPassword" value={editUser.confirmPassword} onChange={handleEditChange} required />
              
              <label>Roles</label>
              <input type="text" name="roles" value={editUser.roles} onChange={handleEditChange} required />
              
              <button type="submit">Update User</button>
            </form>
          </div>
        )}

        <div className="user-list">
          <h2>User List</h2>
          {showMessage && <div className="success-notification">{showMessage}</div>}
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Roles</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id}>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.mobile}</td>
                  <td>{user.roles}</td>
                  <td>
                    <button onClick={() => { setEditUser(user); setShowEditForm(true); }}>Edit</button>
                    <button onClick={() => deleteUser(user.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="property-list">
          <h2>Property List</h2>
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Price</th>
                <th>Location</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {properties.map(property => (
                <tr key={property.id}>
                  <td>{property.title}</td>
                  <td>{property.description}</td>
                  <td>{property.price}</td>
                  <td>{property.location}</td>
                  <td>
                    <button>Edit</button>
                    <button onClick={() => deleteProperty(property.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}

export default AdminPage;
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './admin.css';

// function UserDashboard() {
//   const [isSidebarOpen, setSidebarOpen] = useState(false);
//   const [isUserDropdownOpen, setUserDropdownOpen] = useState(false);
//   const [users, setUsers] = useState([]);
//   const [newUser, setNewUser] = useState({ name: '', email: '', mobile: '', password: '', confirmPassword: '', roles: '' });
//   const [editUser, setEditUser] = useState(null); // State to manage the user being edited
//   const [showForm, setShowForm] = useState(false); // State to manage form visibility
//   const [showEditForm, setShowEditForm] = useState(false); // State to manage edit form visibility
//   const [error, setError] = useState(null);
//   const [success, setSuccess] = useState(null);
//   const [showMessage, setShowMessage] = useState('');

//   useEffect(() => {
//     fetchUsers();
//   }, []);

//   const fetchUsers = () => {
//     axios.get('http://localhost:8080/api/users/all')
//       .then(response => {
//         setUsers(response.data);
//       })
//       .catch(error => {
//         console.error('There was an error fetching the users!', error);
//         setError('There was an error fetching the users.');
//       });
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setNewUser(prevState => ({ ...prevState, [name]: value }));
//   };

//   const handleEditChange = (e) => {
//     const { name, value } = e.target;
//     setEditUser(prevState => ({ ...prevState, [name]: value }));
//   };

//   const addUser = (e) => {
//     e.preventDefault();
//     axios.post('http://localhost:8080/api/users', newUser)
//       .then(response => {
//         setUsers([...users, response.data]);
//         setNewUser({ name: '', email: '', mobile: '', password: '', confirmPassword: '', roles: '' });
//         setError(null);
//         setSuccess('User added successfully.');
//         setShowMessage('User added successfully!');
//         setTimeout(() => setShowMessage(''), 3000);
//       })
//       .catch(error => {
//         console.error('There was an error adding the user!', error);
//         setError('There was an error adding the user.');
//         setSuccess(null);
//       });
//   };

//   const updateUser = (e) => {
//     e.preventDefault();
//     axios.put(`http://localhost:8080/api/users/${editUser.id}`, editUser)
//       .then(response => {
//         const updatedUsers = users.map(user => user.id === editUser.id ? response.data : user);
//         setUsers(updatedUsers);
//         setEditUser(null);
//         setShowEditForm(false);
//         setError(null);
//         setSuccess('User updated successfully.');
//         setShowMessage('User updated successfully!');
//         setTimeout(() => setShowMessage(''), 3000);
//       })
//       .catch(error => {
//         console.error('There was an error updating the user!', error);
//         setError('There was an error updating the user.');
//         setSuccess(null);
//       });
//   };

//   const deleteUser = (id) => {
//     axios.delete(`http://localhost:8080/api/users/${id}`)
//       .then(() => {
//         setUsers(users.filter(user => user.id !== id));
//         setError(null);
//         setSuccess('User deleted successfully.');
//         setShowMessage('User deleted successfully!');
//         setTimeout(() => setShowMessage(''), 3000);
//       })
//       .catch(error => {
//         console.error('There was an error deleting the user!', error);
//         setError('There was an error deleting the user.');
//         setSuccess(null);
//       });
//   };

//   const toggleSidebar = () => {
//     setSidebarOpen(!isSidebarOpen);
//   };

//   const toggleUserDropdown = () => {
//     setUserDropdownOpen(!isUserDropdownOpen);
//   };

//   return (
//     <div className="dashboard-container">
//       <header className="header-bar">
//         <i className="fas fa-bars menu-icon" onClick={toggleSidebar}></i>
//         <h1>Welcome Back, <span>🎉</span></h1>
//         <div className="header-actions">
//           <input type="text" placeholder="Search" />
//           <i className="fas fa-bell" onClick={() => { /* Show notifications dropdown */ }}></i>
//           <i className="fas fa-user" onClick={toggleUserDropdown}></i>
//           {isUserDropdownOpen && (
//             <div className="dropdown-menu">
//               <div className="user-details">
//                 <p>John Doe</p>
//                 <p>johndoe@example.com</p>
//               </div>
//               <a href="/profile" className="dropdown-item">Profile</a>
//               <a href="/logout" className="dropdown-item">Logout</a>
//             </div>
//           )}
//         </div>
//       </header>

//       <aside className={`side-menu ${isSidebarOpen ? 'open' : ''}`}>
//         <div className="side-menu-header">
//           <h2>Dashboard</h2>
//           <i className="fas fa-times" onClick={toggleSidebar}></i>
//         </div>
//         <nav className="side-menu-nav">
//           <ul>
//             <li><i className="fas fa-home"></i> Home</li>
//             <li><i className="fas fa-users"></i> Users</li>
//             <li><i className="fas fa-cogs"></i> Settings</li>
//           </ul>
//         </nav>
//         <div className="side-menu-footer">
//           <div className="user-info">
//             <p>John Doe</p>
//             <p>johndoe@example.com</p>
//           </div>
//         </div>
//       </aside>

//       <div className="content-area">
//         <button className="add-user-btn" onClick={() => setShowForm(!showForm)}>Add New User</button>

//         {showForm && (
//           <div className="form-wrapper">
//             <h2>Add New User</h2>
//             {error && <div className="error-notification">{error}</div>}
//             {success && <div className="success-notification">{success}</div>}
//             <form className="add-user-form" onSubmit={addUser}>
//               <label>Name</label>
//               <input type="text" name="name" value={newUser.name} onChange={handleChange} required />
              
//               <label>Email</label>
//               <input type="email" name="email" value={newUser.email} onChange={handleChange} required />
              
//               <label>Mobile</label>
//               <input type="text" name="mobile" value={newUser.mobile} onChange={handleChange} required />
              
//               <label>Password</label>
//               <input type="password" name="password" value={newUser.password} onChange={handleChange} required />
              
//               <label>Confirm Password</label>
//               <input type="password" name="confirmPassword" value={newUser.confirmPassword} onChange={handleChange} required />
              
//               <label>Roles</label>
//               <input type="text" name="roles" value={newUser.roles} onChange={handleChange} required />
              
//               <button type="submit">Add User</button>
//             </form>
//           </div>
//         )}

//         {showEditForm && editUser && (
//           <div className="form-wrapper">
//             <h2>Edit User</h2>
//             {error && <div className="error-notification">{error}</div>}
//             {success && <div className="success-notification">{success}</div>}
//             <form className="add-user-form" onSubmit={updateUser}>
//               <label>Name</label>
//               <input type="text" name="name" value={editUser.name} onChange={handleEditChange} required />
              
//               <label>Email</label>
//               <input type="email" name="email" value={editUser.email} onChange={handleEditChange} required />
              
//               <label>Mobile</label>
//               <input type="text" name="mobile" value={editUser.mobile} onChange={handleEditChange} required />
              
//               <label>Password</label>
//               <input type="password" name="password" value={editUser.password} onChange={handleEditChange} />
              
//               <label>Confirm Password</label>
//               <input type="password" name="confirmPassword" value={editUser.confirmPassword} onChange={handleEditChange} />
              
//               <label>Roles</label>
//               <input type="text" name="roles" value={editUser.roles} onChange={handleEditChange} required />
              
//               <button type="submit">Update User</button>
//             </form>
//           </div>
//         )}

//         {showMessage && <div className="success-notification">{showMessage}</div>}

//         <div className="overview-container">
//           <div className="overview-card">Card 1</div>
//           <div className="overview-card">Card 2</div>
//           <div className="overview-card">Card 3</div>
//         </div>

//         <table className="user-list-table">
//           <thead>
//             <tr>
//               <th>Name</th>
//               <th>Email</th>
//               <th>Mobile</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {users.map(user => (
//               <tr key={user.id}>
//                 <td>{user.name}</td>
//                 <td>{user.email}</td>
//                 <td>{user.mobile}</td>
//                 <td>
//                   <button className="edit-user-btn" onClick={() => { setEditUser(user); setShowEditForm(true); }}>Edit</button>
//                   <button className="delete-user-btn" onClick={() => deleteUser(user.id)}>Delete</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       <footer className="page-footer">
//         <p>© 2024 Your Company. All rights reserved.</p>
//       </footer>
//     </div>
//   );
// }

// export default UserDashboard;
