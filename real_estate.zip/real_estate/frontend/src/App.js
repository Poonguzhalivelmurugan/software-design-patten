
import React from 'react';
import { Outlet, Route, Routes, useLocation } from 'react-router-dom';
import AboutPage from './components/about';
import ContactPage from './components/contact';
import RentPage from './components/rent';
import RentPaymentPage from './components/rentpayment';
import RentPropDetail from './components/rentprop';
import ReportIssuePage from './components/reportissue';
import UserDashboard from './components/userdas';
import AdminDashboard from './context/admin';
import PropertyDetails from './context/prodetails';
import { PropertyProvider } from './context/propertycontext'; 
import BuyPage from './pages/Buy';
import Home from './pages/Home';
import LoginPage from './pages/Login';

import Navbar from './pages/Navbar';
import Property from './pages/property';
import SellPage from './pages/sell';
import SignupPage from './pages/signup';
import PropertyDetailsPage from './components/Details';
import BookingForm from './components/book';
import AgentPage from './pages/Agent';
import PropertyInfo from './context/propertyinfo';
import MaintenanceManagement from './components/maintainance';
import LeasePage from './components/tenant';
import PropertyOverview from './pages/propertyover';

function App() {
  const location = useLocation();
  const isAdminPage = location.pathname.startsWith('/admin');

  return (
    <PropertyProvider>
      <div className="App">
        {/* Conditionally render Navbar based on the route */}
        {!isAdminPage && <Navbar />}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/property/:propertyId" element={<PropertyDetails />} />
          <Route path="/login" element={<LoginPage />} />
        
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/property" element={<Property/>}/>
          <Route path="/buy" element={<BuyPage/>}/>
          <Route path="/sell" element={<SellPage/>}/>
          <Route path="/rent" element={<RentPage/>}/>
          <Route path="/logout" element={<Home/>}/>

          <Route path="/rentprop-details/:propertyId" element={<RentPropDetail />} />
          <Route path="/admin" element={<AdminDashboard/>}/>
          <Route path="/about" element={<AboutPage/>}/>
          <Route path="/contact" element={<ContactPage/>}/>
          <Route path="/my-account" element={<UserDashboard/>}/>
          <Route path="/propertyinfo" element={<PropertyInfo/>}/> 
          <Route path="/rent-payment" element={<RentPaymentPage/>}/>
          <Route path="/report-issue" element={<ReportIssuePage/>}/>
          <Route path="/tenant" element={<LeasePage/>}/>
          <Route path="/src/components/book.js" element={<BookingForm/>}/>
          <Route path="/agent" element={<AgentPage/>}/> 
          <Route path="/maintainance" element={<MaintenanceManagement/>}/>
          <Route path="/propertyover" element={<PropertyOverview/>}/>
        </Routes>
      </div>
    </PropertyProvider>
  );
}

export default App;
// import React from 'react';
// import { Outlet, Route, Routes } from 'react-router-dom';
// import AboutPage from './components/about';
// import ContactPage from './components/contact';

// import RentPage from './components/rent';
// import RentPaymentPage from './components/rentpayment';
// import RentPropDetail from './components/rentprop';
// import ReportIssuePage from './components/reportissue';
// import UserDashboard from './components/userdas';
// import AdminDashboard from './context/admin';
// import PropertyDetails from './context/prodetails';
// import { PropertyProvider } from './context/propertycontext'; 
// import BuyPage from './pages/Buy';
// import Home from './pages/Home';
// import LoginPage from './pages/Login';
// import Navbar from './pages/Navbar';
// import Property from './pages/property';
// import SellPage from './pages/sell';
// import SignupPage from './pages/signup';
// import PropertyDetailsPage from './components/Details';
// import BookingForm from './components/book';
// import AgentPage from './pages/Agent';
// import PropertyInfo from './context/propertyinfo';
// import MaintenanceManagement from './components/maintainance';
// import LeasePage from './components/tenant';
// import PropertyOverview from './pages/propertyover';


// function App() {
//   return (
//     <PropertyProvider>
//       <div className="App">
//         <Navbar />
//           <Outlet />
//         <Routes>
//           <Route path="/" element={<Home />} />
//           <Route path="/property/:propertyId" element={<PropertyDetails />} />
//           <Route path="/login" element={<LoginPage />} />
//           <Route path="/signup" element={<SignupPage />} />
//           <Route path="/property" element={<Property/>}/>
//           <Route path="/buy" element={<BuyPage/>}/>
//           <Route path="/sell" element={<SellPage/>}/>
//           <Route path="/rent" element={<RentPage/>}/>
//           <Route path="/rentprop-details/:propertyId" element={<RentPropDetail />} />
//           <Route path="/admin" element={<AdminDashboard/>}/>
//           <Route path="/about" element={<AboutPage/>}/>
//           <Route path="/contact" element={<ContactPage/>}/>
//           <Route path="/my-account" element={<UserDashboard/>}/>
//           {/* <Route path="/homes-for-sale" element={<HomesForSale/>}/> */}
         
//           <Route path="/propertyinfo" element={<PropertyInfo/>}/> 
//           <Route path="/rent-payment" element={<RentPaymentPage/>}/>
//           <Route path="/report-issue" element={<ReportIssuePage/>}/>
//           <Route path="/tenant" element={<LeasePage/>}/>
//           <Route path="/src/components/book.js" element={<BookingForm/>}/>
//            <Route path="/agent" element={<AgentPage/>}/> 
//            <Route path="/maintainance" element={<MaintenanceManagement/>}/>
//            <Route path="/propertyover" element={<PropertyOverview/>}/>
//         </Routes>
//       </div>
//     </PropertyProvider>
//   );
// }

// export default App;
