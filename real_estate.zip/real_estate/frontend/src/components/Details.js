import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Details.css'; // Ensure this CSS file is created and included

const PropertyDetailsPage = () => {
  const location = useLocation();
  const { property } = location.state;
  const navigate = useNavigate();

  const handleRentPayment = () => {
    navigate('/rent-payment', { state: { property } });
  };

  const handleReportIssue = () => {
    navigate('/report-issue', { state: { property } });
  };

  const handleViewLeaseAgreement = () => {
    navigate('/lease-agreement', { state: { property } });
  };

  const handleOnboardTenant = () => {
    navigate('/onboard-tenant', { state: { property } });
  };

  return (
    <div className="property-details-page">
      <h1>{property.title}</h1>
      <img src={property.image} alt={`Property ${property.id}`} />
      <p>{property.price} {property.otherCharges}</p>
      <p>{property.size} For Rent in {property.address}</p>
      <p>{property.description}</p>
      <p>Owner: {property.ownerName}</p>
      <p>Status: {property.status}</p>
      <p>Furnished Status: {property.furnishedStatus}</p>
      <p>Age of Construction: {property.ageOfConstruction}</p>
      <p>Contact: {property.contact}</p>
      <div className="buttons">
        <button className="btn" onClick={handleRentPayment}>Make Payment</button>
        <button className="btn" onClick={handleReportIssue}>Report Issue</button>
        <button className="btn" onClick={handleViewLeaseAgreement}>View Lease Agreement</button>
        <button className="btn" onClick={handleOnboardTenant}>Onboard Tenant</button>
      </div>
    </div>
  );
};

export default PropertyDetailsPage;
