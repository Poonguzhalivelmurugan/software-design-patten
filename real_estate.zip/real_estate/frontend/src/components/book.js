import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './book.css'; // Ensure this CSS file is created and included

const BookingForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    message: ''
  });
  
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const isAuthenticated = useSelector(state => state.user.isAuthenticated);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validate = () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
      setErrorMessage('All fields are required.');
      return false;
    }
    setErrorMessage('');
    return true;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const isValid = validate();

    if (isValid) {
      try {
        if (!isAuthenticated) {
          navigate('/login');
        } else {
          const response = await axios.post('http://localhost:8080/api/books', {
            name: formData.name,
            email: formData.email,
            phoneNumber: formData.phone, // Ensure the backend field names match
            date: formData.date,
            time: formData.time,
            description: formData.message,
          });

          if (response.status === 200 || response.status === 201) {
            setSuccessMessage('Booking request submitted successfully!');
            setFormData({
              name: '',
              email: '',
              phone: '',
              date: '',
              time: '',
              message: '',
            });
          } else {
            setErrorMessage('Failed to submit booking request.');
          }
        }
      } catch (error) {
        console.error('Error:', error);
        setErrorMessage('Error submitting booking request.');
      }
    }
  };

  return (
    <div className="booking-container">
      <div className="booking-form-container">
        <form className="booking-form" onSubmit={handleSubmit}>
          <h2>Book a Viewing</h2>
          {successMessage && <p className="success-message">{successMessage}</p>}
          {errorMessage && <p className="error-message">{errorMessage}</p>}
          <div className="form-group">
            <label>Name</label>
            <input 
              type="text" 
              name="name" 
              value={formData.name} 
              onChange={handleChange} 
              required 
            />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input 
              type="email" 
              name="email" 
              value={formData.email} 
              onChange={handleChange} 
              required 
            />
          </div>
          <div className="form-group">
            <label>Phone</label>
            <input 
              type="tel" 
              name="phone" 
              value={formData.phone} 
              onChange={handleChange} 
              required 
            />
          </div>
          <div className="form-group">
            <label>Date</label>
            <input 
              type="date" 
              name="date" 
              value={formData.date} 
              onChange={handleChange} 
              required 
            />
          </div>
          <div className="form-group">
            <label>Time</label>
            <input 
              type="time" 
              name="time" 
              value={formData.time} 
              onChange={handleChange} 
              required 
            />
          </div>
          <div className="form-group">
            <label>Message</label>
            <textarea 
              name="message" 
              value={formData.message} 
              onChange={handleChange} 
            />
          </div>
          <button type="submit" className="btn">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default BookingForm;// // // import axios from 'axios';
// // // import React, { useEffect, useState } from 'react';
// // // import './book.css'; // Ensure this CSS file is created and included

// // // const BookingForm = () => {
// // //   const [formData, setFormData] = useState({
// // //     name: '',
// // //     email: '',
// // //     phone: '',
// // //     date: '',
// // //     time: '',
// // //     message: ''
// // //   });
  
// // //   const [successMessage, setSuccessMessage] = useState('');
// // //   const [errorMessage, setErrorMessage] = useState('');
// // //   const [isAuthenticated, setIsAuthenticated] = useState(false);
// // //   const [loading, setLoading] = useState(true);

// // //   useEffect(() => {
// // //     const token = localStorage.getItem('authToken');
// // //     if (token) {
// // //       axios.get('http://localhost:8080/api/users/current', {
// // //         headers: {
// // //           Authorization: `Bearer ${token}`
// // //         }
// // //       })
// // //       .then(response => {
// // //         setIsAuthenticated(true);
// // //         setLoading(false);
// // //       })
// // //       .catch(() => {
// // //         setIsAuthenticated(false);
// // //         setLoading(false);
// // //       });
// // //     } else {
// // //       setIsAuthenticated(false);
// // //       setLoading(false);
// // //     }
// // //   }, []);

// // //   const handleChange = (e) => {
// // //     setFormData({ ...formData, [e.target.name]: e.target.value });
// // //   };

// // //   const validate = () => {
// // //     if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
// // //       setErrorMessage('All fields are required.');
// // //       return false;
// // //     }
// // //     setErrorMessage('');
// // //     return true;
// // //   };

// // //   const handleSubmit = async (event) => {
// // //     event.preventDefault();
// // //     const isValid = validate();

// // //     if (isValid) {
// // //       if (isAuthenticated) {
// // //         try {
// // //           const response = await axios.post('http://localhost:8080/api/books', {
// // //             name: formData.name,
// // //             email: formData.email,
// // //             phoneNumber: formData.phone, // Ensure the backend field names match
// // //             date: formData.date,
// // //             time: formData.time,
// // //             description: formData.message,
// // //           });

// // //           if (response.status === 200 || response.status === 201) {
// // //             setSuccessMessage('Booking request submitted successfully!');
// // //             setFormData({
// // //               name: '',
// // //               email: '',
// // //               phone: '',
// // //               date: '',
// // //               time: '',
// // //               message: '',
// // //             });
// // //           } else {
// // //             setErrorMessage('Failed to submit booking request.');
// // //           }
// // //         } catch (error) {
// // //           console.error('Error:', error);
// // //           setErrorMessage('Error submitting booking request.');
// // //         }
// // //       } else {
// // //         // Redirect to login page if not authenticated
// // //         localStorage.setItem('redirectAfterLogin', '/booking'); // Save the path to redirect after login
// // //         window.location.href = '/login'; // Redirect to login page
// // //       }
// // //     }
// // //   };

// // //   if (loading) return <p>Loading...</p>;

// // //   return (
// // //     <div className="booking-container">
// // //       <div className="booking-image">
// // //         {/* Optional: Add a title or description here if needed */}
// // //       </div>
// // //       <div className="booking-form-container">
// // //         <form className="booking-form" onSubmit={handleSubmit}>
// // //           <h2>Book a Viewing</h2>
// // //           {successMessage && <p className="success-message">{successMessage}</p>}
// // //           {errorMessage && <p className="error-message">{errorMessage}</p>}
// // //           <div className="form-group">
// // //             <label>Name</label>
// // //             <input 
// // //               type="text" 
// // //               name="name" 
// // //               value={formData.name} 
// // //               onChange={handleChange} 
// // //               required 
// // //             />
// // //           </div>
// // //           <div className="form-group">
// // //             <label>Email</label>
// // //             <input 
// // //               type="email" 
// // //               name="email" 
// // //               value={formData.email} 
// // //               onChange={handleChange} 
// // //               required 
// // //             />
// // //           </div>
// // //           <div className="form-group">
// // //             <label>Phone</label>
// // //             <input 
// // //               type="tel" 
// // //               name="phone" 
// // //               value={formData.phone} 
// // //               onChange={handleChange} 
// // //               required 
// // //             />
// // //           </div>
// // //           <div className="form-group">
// // //             <label>Preferred Date</label>
// // //             <input 
// // //               type="date" 
// // //               name="date" 
// // //               value={formData.date} 
// // //               onChange={handleChange} 
// // //               required 
// // //             />
// // //           </div>
// // //           <div className="form-group">
// // //             <label>Preferred Time</label>
// // //             <input 
// // //               type="time" 
// // //               name="time" 
// // //               value={formData.time} 
// // //               onChange={handleChange} 
// // //               required 
// // //             />
// // //           </div>
// // //           <div className="form-group">
// // //             <label>Message</label>
// // //             <textarea 
// // //               name="message" 
// // //               value={formData.message} 
// // //               onChange={handleChange} 
// // //             ></textarea>
// // //           </div>
// // //           <button type="submit" className="btn">Submit</button>
// // //         </form>
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default BookingForm;
// // import React, { useState, useEffect } from 'react';
// // import axios from 'axios';
// // import './book.css'; // Ensure this CSS file is created and included

// // const BookingForm = () => {
// //   const [formData, setFormData] = useState({
// //     name: '',
// //     email: '',
// //     phone: '',
// //     date: '',
// //     time: '',
// //     message: ''
// //   });
  
// //   const [successMessage, setSuccessMessage] = useState('');
// //   const [errorMessage, setErrorMessage] = useState('');
// //   const [isAuthenticated, setIsAuthenticated] = useState(false);
// //   const [showLoginModal, setShowLoginModal] = useState(false);

// //   useEffect(() => {
// //     // Check if user is authenticated
// //     const token = localStorage.getItem('authToken');
// //     if (token) {
// //       axios.get('http://localhost:8080/api/users/current', {
// //         headers: {
// //           Authorization: `Bearer ${token}`
// //         }
// //       })
// //       .then(response => {
// //         setIsAuthenticated(true);
// //       })
// //       .catch(() => {
// //         setIsAuthenticated(false);
// //       });
// //     } else {
// //       setIsAuthenticated(false);
// //     }
// //   }, []);

// //   const handleChange = (e) => {
// //     setFormData({ ...formData, [e.target.name]: e.target.value });
// //   };

// //   const validate = () => {
// //     if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
// //       setErrorMessage('All fields are required.');
// //       return false;
// //     }
// //     setErrorMessage('');
// //     return true;
// //   };

// //   const handleSubmit = async (event) => {
// //     event.preventDefault();
// //     const isValid = validate();

// //     if (isValid) {
// //       if (isAuthenticated) {
// //         try {
// //           const response = await axios.post('http://localhost:8080/api/books', {
// //             name: formData.name,
// //             email: formData.email,
// //             phoneNumber: formData.phone, // Ensure the backend field names match
// //             date: formData.date,
// //             time: formData.time,
// //             description: formData.message,
// //           });

// //           if (response.status === 200 || response.status === 201) {
// //             setSuccessMessage('Booking request submitted successfully!');
// //             setFormData({
// //               name: '',
// //               email: '',
// //               phone: '',
// //               date: '',
// //               time: '',
// //               message: '',
// //             });
// //           } else {
// //             setErrorMessage('Failed to submit booking request.');
// //           }
// //         } catch (error) {
// //           console.error('Error:', error);
// //           setErrorMessage('Error submitting booking request.');
// //         }
// //       } else {
// //         setShowLoginModal(true);
// //       }
// //     }
// //   };

// //   const handleLoginRedirect = () => {
// //     // Redirect to login page
// //     window.location.href = '/login'; // Adjust the path to your login page
// //   };

// //   const handleCloseModal = () => {
// //     setShowLoginModal(false);
// //   };

// //   return (
// //     <div className="booking-container">
// //       <div className="booking-image">
// //         {/* Optional: Add a title or description here if needed */}
// //       </div>
// //       <div className="booking-form-container">
// //         <form className="booking-form" onSubmit={handleSubmit}>
// //           <h2>Book a Viewing</h2>
// //           {successMessage && <p className="success-message">{successMessage}</p>}
// //           {errorMessage && <p className="error-message">{errorMessage}</p>}
// //           <div className="form-group">
// //             <label>Name</label>
// //             <input 
// //               type="text" 
// //               name="name" 
// //               value={formData.name} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Email</label>
// //             <input 
// //               type="email" 
// //               name="email" 
// //               value={formData.email} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Phone</label>
// //             <input 
// //               type="tel" 
// //               name="phone" 
// //               value={formData.phone} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Preferred Date</label>
// //             <input 
// //               type="date" 
// //               name="date" 
// //               value={formData.date} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Preferred Time</label>
// //             <input 
// //               type="time" 
// //               name="time" 
// //               value={formData.time} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Message</label>
// //             <textarea 
// //               name="message" 
// //               value={formData.message} 
// //               onChange={handleChange} 
// //             ></textarea>
// //           </div>
// //           <button type="submit" className="btn">Submit</button>
// //         </form>

// //         {showLoginModal && (
// //           <div className="login-modal">
// //             <div className="modal-content">
// //               <span className="close" onClick={handleCloseModal}>&times;</span>
// //               <h2>Please log in to continue</h2>
// //               <button onClick={handleLoginRedirect} className="btn">Go to Login</button>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //     </div>
// //   );
// // };

// // export default BookingForm;
// // import axios from 'axios';
// // import React, { useState } from 'react';
// // import './book.css'; // Ensure this CSS file is created and included

// // const BookingForm = () => {
// //   const [formData, setFormData] = useState({
// //     name: '',
// //     email: '',
// //     phone: '',
// //     date: '',
// //     time: '',
// //     message: ''
// //   });
  
// //   const [successMessage, setSuccessMessage] = useState('');
// //   const [errorMessage, setErrorMessage] = useState('');

// //   // Handle input changes
// //   const handleChange = (e) => {
// //     setFormData({ ...formData, [e.target.name]: e.target.value });
// //   };

// //   // Simple validation function
// //   const validate = () => {
// //     if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
// //       setErrorMessage('All fields are required.');
// //       return false;
// //     }
// //     setErrorMessage('');
// //     return true;
// //   };

// //   // Handle form submission
// //   const handleSubmit = async (event) => {
// //     event.preventDefault();
// //     const isValid = validate();

// //     if (isValid) {
// //       try {
// //         const response = await axios.post('http://localhost:8080/api/books', {
// //           name: formData.name,
// //           email: formData.email,
// //           phoneNumber: formData.phone, // Ensure the backend field names match
// //           date: formData.date,
// //           time: formData.time,
// //           description: formData.message,
// //         });

// //         if (response.status === 200 || response.status === 201) {
// //           setSuccessMessage('Booking request submitted successfully!');
// //           setFormData({
// //             name: '',
// //             email: '',
// //             phone: '',
// //             date: '',
// //             time: '',
// //             message: '',
// //           });
// //         } else {
// //           setErrorMessage('Failed to submit booking request.');
// //         }
// //       } catch (error) {
// //         console.error('Error:', error);
// //         setErrorMessage('Error submitting booking request.');
// //       }
// //     }
// //   };

// //   return (
// //     <div className="booking-container">
// //       <div className="booking-image">
// //         {/* Optional: Add a title or description here if needed */}
// //       </div>
// //       <div className="booking-form-container">
// //         <form className="booking-form" onSubmit={handleSubmit}>
// //           <h2>Book a Viewing</h2>
// //           {successMessage && <p className="success-message">{successMessage}</p>}
// //           {errorMessage && <p className="error-message">{errorMessage}</p>}
// //           <div className="form-group">
// //             <label>Name</label>
// //             <input 
// //               type="text" 
// //               name="name" 
// //               value={formData.name} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Email</label>
// //             <input 
// //               type="email" 
// //               name="email" 
// //               value={formData.email} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Phone</label>
// //             <input 
// //               type="tel" 
// //               name="phone" 
// //               value={formData.phone} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Preferred Date</label>
// //             <input 
// //               type="date" 
// //               name="date" 
// //               value={formData.date} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Preferred Time</label>
// //             <input 
// //               type="time" 
// //               name="time" 
// //               value={formData.time} 
// //               onChange={handleChange} 
// //               required 
// //             />
// //           </div>
// //           <div className="form-group">
// //             <label>Message</label>
// //             <textarea 
// //               name="message" 
// //               value={formData.message} 
// //               onChange={handleChange} 
// //             ></textarea>
// //           </div>
// //           <button type="submit" className="btn">Submit</button>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // };

// // export default BookingForm;
// import axios from 'axios';
// import React, { useState } from 'react';
// import './book.css'; // Ensure this CSS file is created and included

// const BookingForm = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     phone: '',
//     date: '',
//     time: '',
//     message: ''
//   });
  
//   const [successMessage, setSuccessMessage] = useState('');
//   const [errorMessage, setErrorMessage] = useState('');

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const validate = () => {
//     if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
//       setErrorMessage('All fields are required.');
//       return false;
//     }
//     setErrorMessage('');
//     return true;
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     const isValid = validate();

//     if (isValid) {
//       try {
//         const response = await axios.post('http://localhost:8080/api/books', {
//           name: formData.name,
//           email: formData.email,
//           phoneNumber: formData.phone, // Ensure the backend field names match
//           date: formData.date,
//           time: formData.time,
//           description: formData.message,
//         });

//         if (response.status === 200 || response.status === 201) {
//           setSuccessMessage('Booking request submitted successfully!');
//           setFormData({
//             name: '',
//             email: '',
//             phone: '',
//             date: '',
//             time: '',
//             message: '',
//           });
//         } else {
//           setErrorMessage('Failed to submit booking request.');
//         }
//       } catch (error) {
//         console.error('Error:', error);
//         setErrorMessage('Error submitting booking request.');
//       }
//     }
//   };

//   return (
//     <div className="booking-container">
//       <div className="booking-image">
//         {/* Optional: Add a title or description here if needed */}
//       </div>
//       <div className="booking-form-container">
//         <form className="booking-form" onSubmit={handleSubmit}>
//           <h2>Book a Viewing</h2>
//           {successMessage && <p className="success-message">{successMessage}</p>}
//           {errorMessage && <p className="error-message">{errorMessage}</p>}
//           <div className="form-group">
//             <label>Name</label>
//             <input 
//               type="text" 
//               name="name" 
//               value={formData.name} 
//               onChange={handleChange} 
//               required 
//             />
//           </div>
//           <div className="form-group">
//             <label>Email</label>
//             <input 
//               type="email" 
//               name="email" 
//               value={formData.email} 
//               onChange={handleChange} 
//               required 
//             />
//           </div>
//           <div className="form-group">
//             <label>Phone</label>
//             <input 
//               type="tel" 
//               name="phone" 
//               value={formData.phone} 
//               onChange={handleChange} 
//               required 
//             />
//           </div>
//           <div className="form-group">
//             <label>Date</label>
//             <input 
//               type="date" 
//               name="date" 
//               value={formData.date} 
//               onChange={handleChange} 
//               required 
//             />
//           </div>
//           <div className="form-group">
//             <label>Time</label>
//             <input 
//               type="time" 
//               name="time" 
//               value={formData.time} 
//               onChange={handleChange} 
//               required 
//             />
//           </div>
//           <div className="form-group">
//             <label>Message</label>
//             <textarea 
//               name="message" 
//               value={formData.message} 
//               onChange={handleChange} 
//               placeholder="Additional details or requests" 
//             />
//           </div>
//           <button type="submit" className="btn">Submit</button>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default BookingForm;
