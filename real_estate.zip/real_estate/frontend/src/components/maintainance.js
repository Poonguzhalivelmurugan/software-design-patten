import axios from 'axios';
import React, { useState } from 'react';
import './maintainance.css'; // Import the CSS file

const MaintenanceForm = () => {
  const [issueDescription, setIssueDescription] = useState('');
  const [priority, setPriority] = useState('');
  const [category, setCategory] = useState('');
  const [propertyAddress, setPropertyAddress] = useState('');
  const [unitNumber, setUnitNumber] = useState('');
  const [contactName, setContactName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [imageBase64, setImageBase64] = useState('');
  const [documentBase64, setDocumentBase64] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleFileChange = (e, setBase64) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBase64(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const requestData = {
      issueDescription,
      priority,
      category,
      propertyAddress,
      unitNumber,
      contactName,
      phoneNumber,
      email,
      imageBase64,
      documentBase64
    };

    try {
      const response = await axios.post('http://localhost:8080/api/maintenance-requests', requestData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (response.status === 200 || response.status === 201) {
        setSuccessMessage('Maintenance request submitted successfully!');
      } else {
        setErrorMessage('Failed to submit maintenance request.');
      }
    } catch (error) {
      setErrorMessage('Error submitting maintenance request: ' + (error.response ? error.response.data : error.message));
    }
  };

  return (
    <div className="maintenance-form-container">
      <h1>Submit Maintenance Request</h1>
      <form onSubmit={handleSubmit} className="maintenance-form">
        <label>
          Property Address:
          <input type="text" value={propertyAddress} onChange={(e) => setPropertyAddress(e.target.value)} required />
        </label>
        <label>
          Unit Number (if applicable):
          <input type="text" value={unitNumber} onChange={(e) => setUnitNumber(e.target.value)} />
        </label>
        <label>
          Issue Description:
          <textarea value={issueDescription} onChange={(e) => setIssueDescription(e.target.value)} required />
        </label>
        <label>
          Priority:
          <select value={priority} onChange={(e) => setPriority(e.target.value)} required>
            <option value="">Select Priority</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </label>
        <label>
          Category:
          <select value={category} onChange={(e) => setCategory(e.target.value)} required>
            <option value="">Select Category</option>
            <option value="Plumbing">Plumbing</option>
            <option value="Electrical">Electrical</option>
            <option value="HVAC">HVAC</option>
            {/* Add more categories as needed */}
          </select>
        </label>
        <label>
          Contact Name:
          <input type="text" value={contactName} onChange={(e) => setContactName(e.target.value)} required />
        </label>
        <label>
          Phone Number:
          <input type="text" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} required />
        </label>
        <label>
          Email Address:
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label>
          Upload Images:
          <input type="file" onChange={(e) => handleFileChange(e, setImageBase64)} />
        </label>
        <label>
          Upload Documents:
          <input type="file" onChange={(e) => handleFileChange(e, setDocumentBase64)} />
        </label>
        <button type="submit">Submit Request</button>
        {successMessage && <div className="message success">{successMessage}</div>}
        {errorMessage && <div className="message error">{errorMessage}</div>}
      </form>
    </div>
  );
};

export default MaintenanceForm;
