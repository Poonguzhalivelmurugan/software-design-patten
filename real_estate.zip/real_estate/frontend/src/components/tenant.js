// import React from 'react';
// import './tenant.css'; // Import the CSS file for styling

// const TenantPage = () => {
//   return (
//     <div className="tenant-page">
//       <header className="header">
//         <h1>Tenant Dashboard</h1>
//       </header>
//       <div className="container">
//         <section className="overview">
//           <h2>Overview</h2>
//           <div className="card">
//             <h3>Current Rental Properties</h3>
//             <p>Details about the properties you are renting.</p>
//           </div>
//           <div className="card">
//             <h3>Upcoming Rent Payments</h3>
//             <p>Summary of your next rent payments.</p>
//           </div>
//           <div className="card">
//             <h3>Recent Notifications</h3>
//             <p>Messages or alerts related to your rental.</p>
//           </div>
//         </section>

//         <section className="property-listings">
//           <h2>Property Listings</h2>
//           <div className="card">
//             <h3>View Details</h3>
//             <p>Details of the properties you are renting.</p>
//           </div>
//           <div className="card">
//             <h3>Search/Filter Properties</h3>
//             <p>Search or filter for other properties (if applicable).</p>
//           </div>
//         </section>

//         <section className="lease-information">
//           <h2>Lease Information</h2>
//           <div className="card">
//             <h3>Current Lease Details</h3>
//             <p>Start and end dates, terms, and renewal options.</p>
//           </div>
//         </section>

//         <section className="payment-management">
//           <h2>Payment Management</h2>
//           <div className="card">
//             <h3>Pay Rent</h3>
//             <p>View and pay your rent.</p>
//           </div>
//           <div className="card">
//             <h3>Payment History</h3>
//             <p>Access your payment history and receipts.</p>
//           </div>
//           <div className="card">
//             <h3>Auto-Pay Setup</h3>
//             <p>Set up auto-pay or save payment methods.</p>
//           </div>
//         </section>

//         <section className="maintenance-requests">
//           <h2>Maintenance Requests</h2>
//           <div className="card">
//             <h3>Submit Requests</h3>
//             <p>Submit and track maintenance or repair requests.</p>
//           </div>
//           <div className="card">
//             <h3>Request Status</h3>
//             <p>View the status of ongoing requests.</p>
//           </div>
//         </section>

//         <section className="communication">
//           <h2>Communication</h2>
//           <div className="card">
//             <h3>Contact Landlord</h3>
//             <p>Messaging system to contact your landlord or property management.</p>
//           </div>
//           <div className="card">
//             <h3>Notifications</h3>
//             <p>Notifications for important updates or reminders.</p>
//           </div>
//         </section>

//         <section className="documents">
//           <h2>Documents</h2>
//           <div className="card">
//             <h3>Access Documents</h3>
//             <p>Lease agreements, payment receipts, and other important documents.</p>
//           </div>
//         </section>

//         <section className="profile-management">
//           <h2>Profile Management</h2>
//           <div className="card">
//             <h3>Update Info</h3>
//             <p>Update personal information, contact details, and more.</p>
//           </div>
//           <div className="card">
//             <h3>Change Password</h3>
//             <p>Manage your account settings and change your password.</p>
//           </div>
//         </section>

//         <section className="support">
//           <h2>Support and Help</h2>
//           <div className="card">
//             <h3>FAQs and Help Articles</h3>
//             <p>Access to FAQs, help articles, or customer support.</p>
//           </div>
//         </section>

//         <section className="security">
//           <h2>Security Features</h2>
//           <div className="card">
//             <h3>Manage Security</h3>
//             <p>Manage security settings like two-factor authentication.</p>
//           </div>
//         </section>
//       </div>
//     </div>
//   );
// };

// export default TenantPage;
// // import React, { useState } from 'react';
// // import { useNavigate } from 'react-router-dom';
// // import './tenant.css';

// // const TenantManagement = () => {
// //   const [profile, setProfile] = useState({ name: '', contact: '', leaseStart: '', leaseEnd: '' });
// //   const [properties, setProperties] = useState([
// //     { id: 1, name: 'Luxury Apartment', description: 'A luxurious apartment in downtown.', image: 'https://butterflymx.com/wp-content/uploads/2021/10/real-estate-photography.jpg', leaseAgreement: 'lease1.pdf' },
// //     { id: 2, name: 'Cozy Studio', description: 'A cozy studio in a quiet neighborhood.', image: 'studio.jpg', leaseAgreement: 'lease2.pdf' }
// //   ]);
// //   const [paymentHistory, setPaymentHistory] = useState([
// //     { date: '2024-08-01', amount: 1200 },
// //     { date: '2024-07-01', amount: 1200 }
// //   ]);
// //   const [issues, setIssues] = useState(['Leaky faucet in the kitchen', 'Heating system not working']);
// //   const [maintenanceRequests, setMaintenanceRequests] = useState(['Replace broken window', 'Fix electrical outlet']);
// //   const [documents, setDocuments] = useState([]);
// //   const [uploadMessage, setUploadMessage] = useState('');
// //   const [selectedProperty, setSelectedProperty] = useState(null);
// //   const [searchTerm, setSearchTerm] = useState('');
// //   const [selectedIssue, setSelectedIssue] = useState(null);
// //   const [selectedMaintenance, setSelectedMaintenance] = useState(null);
// //   const [formVisible, setFormVisible] = useState(true); // State to control form visibility
// //   const navigate = useNavigate(); // For navigation

// //   const handleProfileUpdate = () => {
// //     alert('Profile updated');
// //     setFormVisible(false); // Hide form after update
// //   };

// //   const handlePropertyClick = (property) => {
// //     setSelectedProperty(property);
// //   };

// //   const handleIssueSubmit = (e) => {
// //     e.preventDefault();
// //     const issue = e.target.issue.value;
// //     setIssues([...issues, issue]);
// //     setSelectedIssue(issue);
// //     e.target.reset();
// //   };

// //   const handleMaintenanceSubmit = (e) => {
// //     e.preventDefault();
// //     const maintenance = e.target.request.value;
// //     setMaintenanceRequests([...maintenanceRequests, maintenance]);
// //     setSelectedMaintenance(maintenance);
// //     e.target.reset();
// //   };

// //   const handleDocumentUpload = (event) => {
// //     const uploadedDocument = event.target.files[0];
// //     if (uploadedDocument) {
// //       setDocuments([...documents, uploadedDocument]);
// //       setUploadMessage('Upload successful!');
// //     }
// //   };

// //   const handleIssueClick = (issue) => {
// //     setSelectedIssue(issue);
// //   };

// //   const handleMaintenanceClick = (request) => {
// //     setSelectedMaintenance(request);
// //   };

// //   const handlePaymentRedirect = () => {
// //     navigate('/payment'); // Navigate to PaymentPage
// //   };

// //   const filteredProperties = properties.filter(property =>
// //     property.name.toLowerCase().includes(searchTerm.toLowerCase())
// //   );

// //   return (
// //     <div className="tenant-management-wrapper">
// //       {formVisible && (
// //         <>
// //           <section className="tenant-profile tenant-section">
// //             <h2 className="tenant-header">Tenant Profile</h2>
// //             <form className="tenant-form" onSubmit={(e) => { e.preventDefault(); handleProfileUpdate(); }}>
// //               <input
// //                 className="tenant-input"
// //                 type="text"
// //                 placeholder="Name"
// //                 value={profile.name}
// //                 onChange={(e) => setProfile({ ...profile, name: e.target.value })}
// //                 required
// //               />
// //               <input
// //                 className="tenant-input"
// //                 type="text"
// //                 placeholder="Contact Details"
// //                 value={profile.contact}
// //                 onChange={(e) => setProfile({ ...profile, contact: e.target.value })}
// //                 required
// //               />
// //               <input
// //                 className="tenant-input"
// //                 type="date"
// //                 placeholder="Lease Start Date"
// //                 value={profile.leaseStart}
// //                 onChange={(e) => setProfile({ ...profile, leaseStart: e.target.value })}
// //                 required
// //               />
// //               <input
// //                 className="tenant-input"
// //                 type="date"
// //                 placeholder="Lease End Date"
// //                 value={profile.leaseEnd}
// //                 onChange={(e) => setProfile({ ...profile, leaseEnd: e.target.value })}
// //                 required
// //               />
// //               <button className="tenant-button" type="submit">Update Profile</button>
// //             </form>
// //           </section>

// //           <section className="property-search tenant-section">
// //             <h2 className="tenant-header">Property Search</h2>
// //             <input
// //               className="tenant-input"
// //               type="text"
// //               placeholder="Search for properties..."
// //               value={searchTerm}
// //               onChange={(e) => setSearchTerm(e.target.value)}
// //             />
// //           </section>

// //           <section className="property-listing tenant-section">
// //             <h2 className="tenant-header">Available Properties</h2>
// //             {filteredProperties.length === 0 ? (
// //               <p>No properties available.</p>
// //             ) : (
// //               <ul className="tenant-list">
// //                 {filteredProperties.map((property) => (
// //                   <li
// //                     key={property.id}
// //                     className="tenant-list-item"
// //                     onClick={() => handlePropertyClick(property)}
// //                   >
// //                     <h3>{property.name}</h3>
// //                     <p>{property.description}</p>
// //                     <img src={property.image} alt={property.name} className="property-image"/>
// //                     <button className="tenant-button">View Details</button>
// //                   </li>
// //                 ))}
// //               </ul>
// //             )}
// //           </section>

// //           {selectedProperty && (
// //             <section className="property-details tenant-section">
// //               <h2 className="tenant-header">Property Details</h2>
// //               <h3>{selectedProperty.name}</h3>
// //               <p>{selectedProperty.description}</p>
// //               <img src={selectedProperty.image} alt={selectedProperty.name} className="property-image"/>
// //               <a href={selectedProperty.leaseAgreement} download className="tenant-button">Download Lease Agreement</a>
// //             </section>
// //           )}

// //           <section className="rent-payment tenant-section">
// //             <h2 className="tenant-header">Rent Payment Tracking</h2>
// //             <div className="payment-history">
// //               <h3>Payment History</h3>
// //               {paymentHistory.length === 0 ? (
// //                 <p>No payment history available.</p>
// //               ) : (
// //                 <ul className="tenant-list">
// //                   {paymentHistory.map((payment, index) => (
// //                     <li key={index} className="tenant-list-item">
// //                       <p>Date: {payment.date}</p>
// //                       <p>Amount: ${payment.amount}</p>
// //                     </li>
// //                   ))}
// //                 </ul>
// //               )}
// //             </div>
// //             <div className="rent-reminders">
// //               <h3>Rent Due Reminders</h3>
// //               <p>Upcoming Rent Due: 5 days</p>
// //             </div>
// //             <button className="tenant-button" onClick={handlePaymentRedirect}>Go to Payment Page</button>
// //           </section>

// //           <section className="issue-reporting tenant-section">
// //             <h2 className="tenant-header">Issue Reporting</h2>
// //             <form className="tenant-form" onSubmit={handleIssueSubmit}>
// //               <textarea
// //                 className="tenant-textarea"
// //                 name="issue"
// //                 placeholder="Describe the issue"
// //                 required
// //               />
// //               <button className="tenant-button" type="submit">Report Issue</button>
// //             </form>
// //             <div className="issues-list">
// //               <h3>Reported Issues</h3>
// //               {issues.length === 0 ? (
// //                 <p>No issues reported.</p>
// //               ) : (
// //                 <ul className="tenant-list">
// //                   {issues.map((issue, index) => (
// //                     <li
// //                       key={index}
// //                       className="tenant-list-item"
// //                       onClick={() => handleIssueClick(issue)}
// //                     >
// //                       <p>{issue} - Status: Pending</p>
// //                     </li>
// //                   ))}
// //                 </ul>
// //               )}
// //               {selectedIssue && (
// //                 <div className="issue-details">
// //                   <h3>Issue Details</h3>
// //                   <p>{selectedIssue}</p>
// //                 </div>
// //               )}
// //             </div>
// //           </section>

// //           <section className="maintenance-requests tenant-section">
// //             <h2 className="tenant-header">Maintenance Requests</h2>
// //             <form className="tenant-form" onSubmit={handleMaintenanceSubmit}>
// //               <textarea
// //                 className="tenant-textarea"
// //                 name="request"
// //                 placeholder="Describe maintenance request"
// //                 required
// //               />
// //               <button className="tenant-button" type="submit">Submit Request</button>
// //             </form>
// //             <div className="maintenance-list">
// //               <h3>Maintenance Requests</h3>
// //               {maintenanceRequests.length === 0 ? (
// //                 <p>No maintenance requests submitted.</p>
// //               ) : (
// //                 <ul className="tenant-list">
// //                   {maintenanceRequests.map((request, index) => (
// //                     <li
// //                       key={index}
// //                       className="tenant-list-item"
// //                       onClick={() => handleMaintenanceClick(request)}
// //                     >
// //                       <p>{request} - Status: In Progress</p>
// //                     </li>
// //                   ))}
// //                 </ul>
// //               )}
// //               {selectedMaintenance && (
// //                 <div className="maintenance-details">
// //                   <h3>Maintenance Details</h3>
// //                   <p>{selectedMaintenance}</p>
// //                 </div>
// //               )}
// //             </div>
// //           </section>

// //           <section className="document-management tenant-section">
// //             <h2 className="tenant-header">Document Upload</h2>
// //             <input
// //               type="file"
// //               onChange={handleDocumentUpload}
// //               className="tenant-input"
// //             />
// //             {uploadMessage && <p className="upload-message">{uploadMessage}</p>}
// //             <h3>Uploaded Documents</h3>
// //             {documents.length === 0 ? (
// //               <p>No documents uploaded.</p>
// //             ) : (
// //               <ul className="tenant-list">
// //                 {documents.map((doc, index) => (
// //                   <li key={index} className="tenant-list-item">
// //                     <a href={URL.createObjectURL(doc)} download>{doc.name}</a>
// //                   </li>
// //                 ))}
// //               </ul>
// //             )}
// //           </section>
// //         </>
// //       )}
// //     </div>
// //   );
// // };

// // export default TenantManagement;
import React from 'react';
import './tenant.css'; // Import the CSS file for styling

const LeasePage = () => {
  return (
    <div className="lease-page">
      <div className="lease-header">
        <h1>Lease Details</h1>
      </div>
      <div className="lease-content">
        <section className="lease-overview">
          <h2>Lease Overview</h2>
          <p><strong>Lease Title:</strong> Lease #12345</p>
          <p><strong>Lease Duration:</strong> January 1, 2024 - December 31, 2024</p>
          <p><strong>Property Address:</strong> 123 Main St, Anytown, USA</p>
        </section>

        <section className="lease-details">
          <h2>Lease Details</h2>
          <p><strong>Monthly Rent:</strong> $1,200</p>
          <p><strong>Security Deposit:</strong> $1,200</p>
          <p><strong>Maintenance Responsibilities:</strong> Tenant is responsible for minor repairs and upkeep; landlord handles major repairs.</p>
        </section>

        <section className="payment-info">
          <h2>Payment Information</h2>
          <div className="info-card">
            <h3>Current Rent Status</h3>
            <p>Rent is up to date.</p>
          </div>
          <div className="info-card">
            <h3>Upcoming Payments</h3>
            <p>Next payment due on September 1, 2024.</p>
          </div>
          <div className="info-card">
            <h3>Payment History</h3>
            <p>View <a href="/payment-history">Payment History</a>.</p>
          </div>
        </section>

        <section className="lease-documents">
          <h2>Lease Agreement Document</h2>
          <p>View or download your <a href="/lease-agreement" download>Lease Agreement</a>.</p>
        </section>

        <section className="renewal-options">
          <h2>Renewal Options</h2>
          <p>Renewal terms will be sent 30 days before lease end.</p>
          <p><a href="/renewal-application" className="btn">Apply for Renewal</a></p>
        </section>

        <section className="termination-info">
          <h2>Termination Information</h2>
          <p>Notice period for termination: 30 days.</p>
          <p><a href="/move-out-procedures">Move-Out Procedures</a></p>
        </section>

        <section className="contact-info">
          <h2>Contact Information</h2>
          <p><strong>Landlord:</strong> John Doe</p>
          <p><strong>Phone:</strong> (555) 123-4567</p>
          <p><strong>Email:</strong> johndoe@example.com</p>
        </section>

        <section className="additional-info">
          <h2>Additional Information</h2>
          <p><strong>Property Rules:</strong> No pets, quiet hours from 10 PM to 7 AM.</p>
          <p><strong>Inspection Reports:</strong> View <a href="/inspection-reports">Inspection Reports</a>.</p>
        </section>
      </div>
    </div>
  );
};

export default LeasePage;
