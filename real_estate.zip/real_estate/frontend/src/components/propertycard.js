import React from 'react';
import { Link } from 'react-router-dom';
// import './PropertyCard.css'; // Import your CSS file

const PropertyCard = ({ property }) => {
  return (
    <div className="property-card">
      <img src={property.image} alt={property.address} />
      <div className="property-info">
        <h3>{property.address}</h3>
        <p>{property.description}</p>
        <p>Price: ${property.price}</p>
        <p>Bedrooms: {property.bedrooms}</p>
        <p>Bathrooms: {property.bathrooms}</p>
        <Link to={`/property/${property.id}`}>View Details</Link>
        <button className="save-button">Save</button>
      </div>
    </div>
  );
};

export default PropertyCard;
