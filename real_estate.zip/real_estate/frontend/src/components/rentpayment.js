import React, { useState } from 'react';
import './rentpage.css';

const PaymentSettingsPage = () => {
  const [activeTab, setActiveTab] = useState('account');
  const [paymentData, setPaymentData] = useState({
    cardHolderName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    successMessage: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPaymentData({ ...paymentData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setTimeout(() => {
      setPaymentData({
        ...paymentData,
        successMessage: 'Card added successfully!',
      });
    }, 1000);
  };

  return (
    <div className="payment-settings-page">
      <h1>Settings</h1>
      <div className="payment-tabs">
        <button 
          className={`tab-button ${activeTab === 'account' ? 'active' : ''}`} 
          onClick={() => setActiveTab('account')}
        >
          Account
        </button>
        <button 
          className={`tab-button ${activeTab === 'payment' ? 'active' : ''}`} 
          onClick={() => setActiveTab('payment')}
        >
          Payment
        </button>
      </div>

      {activeTab === 'account' && (
        <div className="account-container">
          <h2>Account Details</h2>
          <p>This section would contain account-related settings and information.</p>
        </div>
      )}

      {activeTab === 'payment' && (
        <div className="payment-container">
          <h2>Saved cards:</h2>
          <div className="saved-card">
            <img src="mastercard.png" alt="Mastercard" />
            <p>**** **** **** 3193</p>
            <button className="remove-card-button">Remove card</button>
          </div>
          <div className="saved-card">
            <img src="visa.png" alt="Visa" />
            <p>**** **** **** 4296</p>
            <button className="remove-card-button">Remove card</button>
          </div>
          <h2>Add new card:</h2>
          <form onSubmit={handleSubmit} className="card-form">
            <div className="form-group">
              <label htmlFor="cardHolderName">Card holder name:</label>
              <input
                type="text"
                id="cardHolderName"
                name="cardHolderName"
                value={paymentData.cardHolderName}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="cardNumber">Card number:</label>
              <input
                type="text"
                id="cardNumber"
                name="cardNumber"
                value={paymentData.cardNumber}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="expiryDate">Exp. date:</label>
                <input
                  type="text"
                  id="expiryDate"
                  name="expiryDate"
                  value={paymentData.expiryDate}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="cvv">CVV:</label>
                <input
                  type="text"
                  id="cvv"
                  name="cvv"
                  value={paymentData.cvv}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
            <button type="submit" className="add-card-button">Add card</button>
          </form>
          {paymentData.successMessage && (
            <div className="success-message">{paymentData.successMessage}</div>
          )}
        </div>
      )}
    </div>
  );
};

export default PaymentSettingsPage;
