import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './userdas.css';

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Function to handle button click
  const handleButtonClick = () => {
    navigate('/admin');
  };
// Inline CSS for modern button styling
const buttonStyle = {
  backgroundColor: '#007bff',  // Primary color
  border: 'none',
  color: 'white',
  padding: '10px 20px',
  textAlign: 'center',
  textDecoration: 'none',
  display: 'inline-block',
  fontSize: '16px',
  borderRadius: '5px',
  boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
  transition: 'background-color 0.3s, transform 0.2s',
  cursor: 'pointer',
};

// Inline CSS for button hover effects
const buttonHoverStyle = {
  backgroundColor: '#0056b3', // Darker shade for hover effect
  transform: 'scale(1.05)',
};

// Button style with hover effect
const [buttonStyleState, setButtonStyleState] = React.useState(buttonStyle);
  useEffect(() => {
    axios.get('http://localhost:8080/api/users/current', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming token is stored in localStorage
      }
    })
      .then(response => {
        setUser(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the user details!', error);
        setError('There was an error fetching the user details.');
      });
  }, []);

  if (error) return <p className="error-message">{error}</p>;
  if (!user) return <p>Loading...</p>;

  return (
    <div className="user-dashboard">
      <h1>Profile</h1>
      <div className="user-details">
        <p><strong>Username:</strong> {user.name}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Role:</strong> {user.roles}</p>
        <p><strong>Phone:</strong> {user.mobile}</p>
        {user.roles === 'Admin' && (
        <button
          onClick={handleButtonClick}
          style={buttonStyle}
          onMouseEnter={() => setButtonStyleState({ ...buttonStyle, ...buttonHoverStyle })}
          onMouseLeave={() => setButtonStyleState(buttonStyle)}
        >
          Move to Admin Dashboard
        </button>
      )}
      </div>
    </div>
  );
};

export default UserDashboard;
