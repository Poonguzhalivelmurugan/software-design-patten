import '@fortawesome/fontawesome-free/css/all.min.css';
import axios from 'axios';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
// import signup from '../assets/signup.jpg'; // Adjust the path as needed
import './signup.css'; // Adjust the path as needed

function SignupPage() {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        mobile: "",
        password: "",
        confirmPassword: ""
    });

    const [errors, setErrors] = useState({
        name: "",
        email: "",
        mobile: "",
        password: "",
        confirmPassword: ""
    });

    const [successMessage, setSuccessMessage] = useState("");
    const [isFormVisible, setFormVisible] = useState(true);

    const navigate = useNavigate();

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({ ...formData, [name]: value });
    };

    const validate = () => {
        let nameError = "";
        let emailError = "";
        let mobileError = "";
        let passwordError = "";
        let confirmPasswordError = "";

        if (!formData.name) {
            nameError = "Name is required";
        }

        if (!formData.email.includes("@")) {
            emailError = "Invalid email address";
        }

        if (formData.password.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(formData.password)) {
            passwordError = "Password must be at least 8 characters long and include a special character";
        }

        if (formData.password !== formData.confirmPassword) {
            confirmPasswordError = "Passwords do not match";
        }

        if (!/^\d{10}$/.test(formData.mobile)) {
            mobileError = "Mobile number must be 10 digits";
        }

        if (nameError || emailError || mobileError || passwordError || confirmPasswordError) {
            setErrors({ name: nameError, email: emailError, mobile: mobileError, password: passwordError, confirmPassword: confirmPasswordError });
            return false;
        }

        return true;
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        const isValid = validate();
        if (isValid) {
            try {
                const response = await axios.post("http://127.0.0.1:8080/api/users", {
                    id: 0,
                    name: formData.name,
                    email: formData.email,
                    password: formData.password,
                    mobile: formData.mobile,
                    roles: "USER",
                });
                if (response.status === 200 || response.status === 201) {
                    setSuccessMessage("Registration successful");
                    navigate('/login');
                } else {
                    alert("User creation failed");
                }
                
            } catch (error) {
                console.error(error);
                alert("Something went wrong");
            }
        }
    };

    return (
        <div className="signup-page">
            <div className={`signup-container ${isFormVisible ? '' : 'hidden'}`}>
                <div className="close-icon" onClick={() => setFormVisible(false)}>
                    <i className="fas fa-times"></i>
                </div>
                <h2>Sign Up</h2>
                {successMessage && <div className="success">{successMessage}</div>}
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Name</label>
                        <input
                            type="text"
                            placeholder="Enter your name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                        {errors.name && <div className="error">{errors.name}</div>}
                    </div>
                    <div className="form-group">
                        <label>Email</label>
                        <input
                            type="email"
                            placeholder="Enter your email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                        {errors.email && <div className="error">{errors.email}</div>}
                    </div>
                    <div className="form-group">
                        <label>Mobile Number</label>
                        <input
                            type="tel"
                            placeholder="Enter your mobile number"
                            name="mobile"
                            value={formData.mobile}
                            onChange={handleChange}
                            required
                        />
                        {errors.mobile && <div className="error">{errors.mobile}</div>}
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            placeholder="Enter your password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            required
                        />
                        {errors.password && <div className="error">{errors.password}</div>}
                    </div>
                    <div className="form-group">
                        <label>Confirm Password</label>
                        <input
                            type="password"
                            placeholder="Confirm your password"
                            name="confirmPassword"
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            required
                        />
                        {errors.confirmPassword && <div className="error">{errors.confirmPassword}</div>}
                    </div>
                    <button type="submit" className="btn1">Sign Up</button>
                    <button type="button" onClick={() => alert('Google Signup is not implemented in this example.')} className="google-btn">
                        Continue with Google
                    </button>
                    <p>
                        Already have an account? <Link to="/login">Login</Link>
                    </p>
                </form>
            </div>
            {/* <div className="signup-image">
                <img src={signup} alt="Real Estate" />
            </div> */}
        </div>
    );
}

export default SignupPage;
