import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/authcontext';
import './sell.css';

// Convert file to Base64 string
const convertToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
  });
};

// Function to handle the sell form submission
const handleSellSubmit = async (event, propertyDetails, setSuccessMessage, setErrorMessage, navigate, isAuthenticated, setPropertyDetails) => {
  event.preventDefault();

  // Check if the user is authenticated before allowing submission
  if (!isAuthenticated) {
    alert('Please sign in to submit details.');
    navigate('/login');
    return;
  }

  const isValid = validateSellForm(propertyDetails, setErrorMessage);

  if (isValid) {
    const requestData = { ...propertyDetails };

    if (propertyDetails.propertyImage) {
      requestData.propertyImage = await convertToBase64(propertyDetails.propertyImage);
    }
    if (propertyDetails.documents) {
      requestData.documents = await convertToBase64(propertyDetails.documents);
    }

    try {
      const response = await axios.post('http://localhost:8080/api/sell', requestData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 200 || response.status === 201) {
        setSuccessMessage('Sell details submitted successfully!');
        // Reset form fields
        setPropertyDetails({
          sellerName: '',
          phoneNumber: '',
          propertyAddress: '',
          propertyDescription: '',
          propertyImage: null,
          documents: null,
        });
      } else {
        setErrorMessage('Failed to submit sell details.');
      }
    } catch (error) {
      console.error('Error:', error.response ? error.response.data : error.message);
      setErrorMessage(error.response ? error.response.data.message : 'Error submitting sell details.');
    }
  }
};

const validateSellForm = (details, setErrorMessage) => {
  const { sellerName, phoneNumber, propertyAddress, propertyDescription, propertyImage, documents } = details;
  if (!sellerName || !phoneNumber || !propertyAddress || !propertyDescription || !propertyImage || !documents) {
    setErrorMessage('All fields are required.');
    return false;
  }
  setErrorMessage('');
  return true;
};

// Function to handle the rent form submission
const handleRentSubmit = async (event, rentDetails, setSuccessMessage, setErrorMessage, navigate, isAuthenticated, setRentDetails) => {
  event.preventDefault();

  // Check if the user is authenticated before allowing submission
  if (!isAuthenticated) {
    alert('Please sign in to submit details.');
    navigate('/login');
    return;
  }

  const isValid = validateRentForm(rentDetails, setErrorMessage);

  if (isValid) {
    const requestData = { ...rentDetails };

    if (rentDetails.rentImage) {
      requestData.rentImage = await convertToBase64(rentDetails.rentImage);
    }
    if (rentDetails.rentDocuments) {
      requestData.rentDocuments = await convertToBase64(rentDetails.rentDocuments);
    }

    try {
      const response = await axios.post('http://localhost:8080/api/rent', requestData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 200 || response.status === 201) {
        setSuccessMessage('Rent details submitted successfully!');
        // Reset form fields
        setRentDetails({
          tenantName: '',
          tenantPhoneNumber: '',
          rentAddress: '',
          rentDescription: '',
          rentImage: null,
          rentDocuments: null,
        });
      } else {
        setErrorMessage('Failed to submit rent details.');
      }
    } catch (error) {
      console.error('Error:', error.response ? error.response.data : error.message);
      setErrorMessage(error.response ? error.response.data.message : 'Error submitting rent details.');
    }
  }
};

const validateRentForm = (details, setErrorMessage) => {
  const { tenantName, tenantPhoneNumber, rentAddress, rentDescription, rentImage, rentDocuments } = details;
  if (!tenantName || !tenantPhoneNumber || !rentAddress || !rentDescription || !rentImage || !rentDocuments) {
    setErrorMessage('All fields are required.');
    return false;
  }
  setErrorMessage('');
  return true;
};

const SellPage = () => {
  const [activeForm, setActiveForm] = useState('sell');
  const [propertyDetails, setPropertyDetails] = useState({
    sellerName: '',
    phoneNumber: '',
    propertyAddress: '',
    propertyDescription: '',
    propertyImage: null,
    documents: null,
  });
  const [rentDetails, setRentDetails] = useState({
    tenantName: '',
    tenantPhoneNumber: '',
    rentAddress: '',
    rentDescription: '',
    rentImage: null,
    rentDocuments: null,
  });
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  const isAuthenticated = useAuth(); // This should be replaced with actual authentication logic

  const handleChange = (e, form) => {
    const { name, value, files } = e.target;
    if (files) {
      if (form === 'sell') {
        setPropertyDetails(prevDetails => ({ ...prevDetails, [name]: files[0] }));
      } else {
        setRentDetails(prevDetails => ({ ...prevDetails, [name]: files[0] }));
      }
    } else {
      if (form === 'sell') {
        setPropertyDetails(prevDetails => ({ ...prevDetails, [name]: value }));
      } else {
        setRentDetails(prevDetails => ({ ...prevDetails, [name]: value }));
      }
    }
  };

  const handleSubmit = async (event, form) => {
    if (form === 'sell') {
      await handleSellSubmit(event, propertyDetails, setSuccessMessage, setErrorMessage, navigate, isAuthenticated, setPropertyDetails);
    } else {
      await handleRentSubmit(event, rentDetails, setSuccessMessage, setErrorMessage, navigate, isAuthenticated, setRentDetails);
    }
  };

  const handleRealChoiceClick = () => {
    navigate('/property'); // Update to the correct path
  };

  const handleSellerMarketplaceClick = () => {
    navigate('/sellers-marketplace'); // Update to the correct path
  };

  const handleEnterHomeAddressClick = () => {
    navigate('/home-estimate'); // Update to the correct path
  };

  return (
    <div className="sell-page">
      <div className="selling-options">
        <div className="option">
          <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-agent-home-sale.svg' alt="get start" />
          <h2>RealChoice<sup>TM</sup> Selling</h2>
          <p>Pick the right agent for you. Answer a few questions and get a list of top agents in your area. Compare their costs and services, and choose the right agent for you.</p>
          <button className="btn" onClick={handleRealChoiceClick}>Get Started</button>
        </div>
        <div className="option">
          <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-instant-offers.svg' alt="mark" />
          <h2>Seller's Marketplace</h2>
          <p>Get offers for your home. Visit Seller’s Marketplace to find out how you can sell without listing or stay in your home while you finance the purchase of your next one.</p>
          <button className="btn" onClick={handleSellerMarketplaceClick}>Explore Offers</button>
        </div>
        <div className="option">
          <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-couple-couch-laptop.svg' alt="mark" />
          <h2>RealEstimate<sup>TM</sup></h2>
          <p>Track your home value. See your RealEstimate<sup>℠</sup> valuation information over time compared to homes in your area.</p>
          <button className="btn88" onClick={handleEnterHomeAddressClick}>Enter home address</button>
        </div>
      </div>
      <div className="form-container">
        <h1>Sell or Rent Your Property</h1>
        <div className="form-toggle">
          <button className={`toggle-btn ${activeForm === 'sell' ? 'active' : ''}`} onClick={() => setActiveForm('sell')}>Sell Form</button>
          <button className={`toggle-btn ${activeForm === 'rent' ? 'active' : ''}`} onClick={() => setActiveForm('rent')}>Rent Form</button>
        </div>
        <div className={`form-section ${activeForm === 'sell' ? 'active' : ''}`}>
          <h2>Sell Your Property</h2>
          <form className="property-form" onSubmit={(e) => handleSubmit(e, 'sell')}>
            <label>
              Seller Name:
              <input type="text" name="sellerName" value={propertyDetails.sellerName} onChange={(e) => handleChange(e, 'sell')} required />
            </label>
            <label>
              Phone Number:
              <input type="text" name="phoneNumber" value={propertyDetails.phoneNumber} onChange={(e) => handleChange(e, 'sell')} required />
            </label>
            <label>
              Property Address:
              <input type="text" name="propertyAddress" value={propertyDetails.propertyAddress} onChange={(e) => handleChange(e, 'sell')} required />
            </label>
            <label>
              Property Description:
              <textarea name="propertyDescription" value={propertyDetails.propertyDescription} onChange={(e) => handleChange(e, 'sell')} required />
            </label>
            <label>
              Property Image:
              <input type="file" name="propertyImage" onChange={(e) => handleChange(e, 'sell')} required />
            </label>
            <label>
              Documents:
              <input type="file" name="documents" onChange={(e) => handleChange(e, 'sell')} required />
            </label>
            <button type="submit">Submit</button>
          </form>
        </div>
        <div className={`form-section ${activeForm === 'rent' ? 'active' : ''}`}>
          <h2>Rent Your Property</h2>
          <form className="property-form" onSubmit={(e) => handleSubmit(e, 'rent')}>
            <label>
              Tenant Name:
              <input type="text" name="tenantName" value={rentDetails.tenantName} onChange={(e) => handleChange(e, 'rent')} required />
            </label>
            <label>
              Phone Number:
              <input type="text" name="tenantPhoneNumber" value={rentDetails.tenantPhoneNumber} onChange={(e) => handleChange(e, 'rent')} required />
            </label>
            <label>
              Rent Address:
              <input type="text" name="rentAddress" value={rentDetails.rentAddress} onChange={(e) => handleChange(e, 'rent')} required />
            </label>
            <label>
              Rent Description:
              <textarea name="rentDescription" value={rentDetails.rentDescription} onChange={(e) => handleChange(e, 'rent')} required />
            </label>
            <label>
              Rent Image:
              <input type="file" name="rentImage" onChange={(e) => handleChange(e, 'rent')} required />
            </label>
            <label>
              Documents:
              <input type="file" name="rentDocuments" onChange={(e) => handleChange(e, 'rent')} required />
            </label>
            <button type="submit">Submit</button>
          </form>
        </div>
        {successMessage && <p className="success-message">{successMessage}</p>}
        {errorMessage && <p className="error-message">{errorMessage}</p>}
      </div>
    </div>
  );
};

export default SellPage;

// import axios from 'axios';
// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import './sell.css';

// const SellPage = () => {
//   const [activeForm, setActiveForm] = useState('sell');
//   const [propertyDetails, setPropertyDetails] = useState({
//     sellerName: '',
//     phoneNumber: '',
//     propertyAddress: '',
//     propertyDescription: '',
//     propertyImage: null,
//     documents: null,
//   });
//   const [rentDetails, setRentDetails] = useState({
//     tenantName: '',
//     tenantPhoneNumber: '',
//     rentAddress: '',
//     rentDescription: '',
//     rentImage: null,
//     rentDocuments: null,
//   });
//   const [successMessage, setSuccessMessage] = useState('');
//   const [errorMessage, setErrorMessage] = useState('');
//   const navigate = useNavigate();
//   const isAuthenticated = true; // This should be replaced with actual authentication logic

//   const handleChange = (e, form) => {
//     const { name, value, files } = e.target;
//     if (files) {
//       if (form === 'sell') {
//         setPropertyDetails(prevDetails => ({ ...prevDetails, [name]: files[0] }));
//       } else {
//         setRentDetails(prevDetails => ({ ...prevDetails, [name]: files[0] }));
//       }
//     } else {
//       if (form === 'sell') {
//         setPropertyDetails(prevDetails => ({ ...prevDetails, [name]: value }));
//       } else {
//         setRentDetails(prevDetails => ({ ...prevDetails, [name]: value }));
//       }
//     }
//   };

//   const validate = (form) => {
//     const details = form === 'sell' ? propertyDetails : rentDetails;
//     const { sellerName, phoneNumber, propertyAddress, propertyDescription, propertyImage, documents } = details;
//     if (!sellerName || !phoneNumber || !propertyAddress || !propertyDescription || !propertyImage || !documents) {
//       setErrorMessage('All fields are required.');
//       return false;
//     }
//     setErrorMessage('');
//     return true;
//   };

//   const handleSubmit = async (event, form) => {
//     event.preventDefault();

//     // Check if the user is authenticated before allowing submission
//     if (!isAuthenticated) {
//       alert('Please sign in to submit details.');
//       navigate('/login');
//       return;
//     }

//     const isValid = validate(form);

//     if (isValid) {
//       const formData = new FormData();
//       const details = form === 'sell' ? propertyDetails : rentDetails;
      
//       // Append form data to FormData
//       Object.keys(details).forEach(key => {
//         formData.append(key, details[key]);
//       });

//       try {
//         const response = await axios.post(`http://localhost:8080/api/${form}`, formData, {
//           headers: {
//             'Content-Type': 'multipart/form-data',
//           },
//         });

//         if (response.status === 200 || response.status === 201) {
//           setSuccessMessage(`${form === 'sell' ? 'Sell' : 'Rent'} details submitted successfully!`);
//           // Reset form fields based on form type
//           if (form === 'sell') {
//             setPropertyDetails({
//               sellerName: '',
//               phoneNumber: '',
//               propertyAddress: '',
//               propertyDescription: '',
//               propertyImage: null,
//               documents: null,
//             });
//           } else {
//             setRentDetails({
//               tenantName: '',
//               tenantPhoneNumber: '',
//               rentAddress: '',
//               rentDescription: '',
//               rentImage: null,
//               rentDocuments: null,
//             });
//           }
//         } else {
//           setErrorMessage('Failed to submit details.');
//         }
//       } catch (error) {
//         console.error('Error:', error.response ? error.response.data : error.message);
//         setErrorMessage(error.response ? error.response.data.message : 'Error submitting details.');
//       }
//     }
//   };

//   const handleRealChoiceClick = () => {
//     navigate('/property'); // Update to the correct path
//   };

//   const handleSellerMarketplaceClick = () => {
//     navigate('/sellers-marketplace'); // Update to the correct path
//   };

//   const handleEnterHomeAddressClick = () => {
//     navigate('/home-estimate'); // Update to the correct path
//   };

//   return (
//     <div className="sell-page">
//       <div className="selling-options">
//         <div className="option">
//           <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-agent-home-sale.svg' alt="get start" />
//           <h2>RealChoice<sup>TM</sup> Selling</h2>
//           <p>Pick the right agent for you. Answer a few questions and get a list of top agents in your area. Compare their costs and services, and choose the right agent for you.</p>
//           <button className="btn" onClick={handleRealChoiceClick}>Get Started</button>
//         </div>
//         <div className="option">
//           <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-instant-offers.svg' alt="mark" />
//           <h2>Seller's Marketplace</h2>
//           <p>Get offers for your home. Visit Seller’s Marketplace to find out how you can sell without listing or stay in your home while you finance the purchase of your next one.</p>
//           <button className="btn" onClick={handleSellerMarketplaceClick}>Explore Offers</button>
//         </div>
//         <div className="option">
//           <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-couple-couch-laptop.svg' alt="mark" />
//           <h2>RealEstimate<sup>TM</sup></h2>
//           <p>Track your home value. See your RealEstimate<sup>℠</sup> valuation information over time compared to homes in your area.</p>
//           <button className="btn" onClick={handleEnterHomeAddressClick}>Enter home address</button>
//         </div>
//       </div>
//       <div className="form-container">
//         <h1>Sell or Rent Your Property</h1>
//         <div className="form-toggle">
//           <button className={`toggle-btn ${activeForm === 'sell' ? 'active' : ''}`} onClick={() => setActiveForm('sell')}>Sell Form</button>
//           <button className={`toggle-btn ${activeForm === 'rent' ? 'active' : ''}`} onClick={() => setActiveForm('rent')}>Rent Form</button>
//         </div>
//         <div className={`form-section ${activeForm === 'sell' ? 'active' : ''}`}>
//           <h2>Sell Your Property</h2>
//           <form className="property-form" onSubmit={(e) => handleSubmit(e, 'sell')}>
//             <label>
//               Seller Name:
//               <input type="text" name="sellerName" value={propertyDetails.sellerName} onChange={(e) => handleChange(e, 'sell')} required />
//             </label>
//             <label>
//               Phone Number:
//               <input type="text" name="phoneNumber" value={propertyDetails.phoneNumber} onChange={(e) => handleChange(e, 'sell')} required />
//             </label>
//             <label>
//               Property Address:
//               <input type="text" name="propertyAddress" value={propertyDetails.propertyAddress} onChange={(e) => handleChange(e, 'sell')} required />
//             </label>
//             <label>
//               Property Description:
//               <textarea name="propertyDescription" value={propertyDetails.propertyDescription} onChange={(e) => handleChange(e, 'sell')} required />
//             </label>
//             <label>
//               Property Image:
//               <input type="file" name="propertyImage" onChange={(e) => handleChange(e, 'sell')} required />
//             </label>
//             <label>
//               Documents:
//               <input type="file" name="documents" onChange={(e) => handleChange(e, 'sell')} required />
//             </label>
//             <button type="submit" className="btn">Submit</button>
//           </form>
//         </div>
//         <div className={`form-section ${activeForm === 'rent' ? 'active' : ''}`}>
//           <h2>Rent Your Property</h2>
//           <form className="property-form" onSubmit={(e) => handleSubmit(e, 'rent')}>
//             <label>
//               Tenant Name:
//               <input type="text" name="tenantName" value={rentDetails.tenantName} onChange={(e) => handleChange(e, 'rent')} required />
//             </label>
//             <label>
//               Phone Number:
//               <input type="text" name="tenantPhoneNumber" value={rentDetails.tenantPhoneNumber} onChange={(e) => handleChange(e, 'rent')} required />
//             </label>
//             <label>
//               Rent Address:
//               <input type="text" name="rentAddress" value={rentDetails.rentAddress} onChange={(e) => handleChange(e, 'rent')} required />
//             </label>
//             <label>
//               Rent Description:
//               <textarea name="rentDescription" value={rentDetails.rentDescription} onChange={(e) => handleChange(e, 'rent')} required />
//             </label>
//             <label>
//               Rent Image:
//               <input type="file" name="rentImage" onChange={(e) => handleChange(e, 'rent')} required />
//             </label>
//             <label>
//               Documents:
//               <input type="file" name="rentDocuments" onChange={(e) => handleChange(e, 'rent')} required />
//             </label>
//             <button type="submit" className="btn">Submit</button>
//           </form>
//         </div>
//         {successMessage && <p className="success-message">{successMessage}</p>}
//         {errorMessage && <p className="error-message">{errorMessage}</p>}
//       </div>
//     </div>
//   );
// };

// export default SellPage;


// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import './sell.css';

// const SellPage = () => {
//   const [propertyDetails, setPropertyDetails] = useState({
//     sellerName: '',
//     phoneNumber: '',
//     propertyAddress: '',
//     propertyDescription: '',
//     propertyImage: null,
//     documents: null,
//   });
//   const [successMessage, setSuccessMessage] = useState('');
//   const [errorMessage, setErrorMessage] = useState('');
//   const navigate = useNavigate();
//   const isAuthenticated = true;

//   const handleChange = (e) => {
//     const { name, value, files } = e.target;
//     if (files) {
//       setPropertyDetails({ ...propertyDetails, [name]: files[0] });
//     } else {
//       setPropertyDetails({ ...propertyDetails, [name]: value });
//     }
//   };

//   const validate = () => {
//     const { sellerName, phoneNumber, propertyAddress, propertyDescription, propertyImage, documents } = propertyDetails;
//     if (!sellerName || !phoneNumber || !propertyAddress || !propertyDescription || !propertyImage || !documents) {
//       setErrorMessage('All fields are required.');
//       return false;
//     }
//     setErrorMessage('');
//     return true;
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();

//     // Check if the user is authenticated before allowing submission
//     if (!isAuthenticated) {
//       alert('Please sign in to upload property details.');
//       navigate('/login');
//       return;
//     }

//     const isValid = validate();

//     if (isValid) {
//       const formData = new FormData();
//       formData.append('sellerName', propertyDetails.sellerName);
//       formData.append('phoneNumber', propertyDetails.phoneNumber);
//       formData.append('propertyAddress', propertyDetails.propertyAddress);
//       formData.append('propertyDescription', propertyDetails.propertyDescription);
//       formData.append('propertyImage', propertyDetails.propertyImage);
//       formData.append('documents', propertyDetails.documents);

//       try {
//         const response = await axios.post('http://localhost:8080/api/sells', formData, {
//           headers: {
//             'Content-Type': 'multipart/form-data',
//           },
//         });

//         if (response.status === 200 || response.status === 201) {
//           setSuccessMessage('Property details submitted successfully!');
//           setPropertyDetails({
//             sellerName: '',
//             phoneNumber: '',
//             propertyAddress: '',
//             propertyDescription: '',
//             propertyImage: null,
//             documents: null,
//           });
//         } else {
//           setErrorMessage('Failed to submit property details.');
//         }
//       } catch (error) {
//         console.error('Error:', error);
//         setErrorMessage('Error submitting property details.');
//       }
//     }
//   };

//   const handleRealChoiceClick = () => {
//     navigate('/property'); // Update to the correct path
//   };

//   const handleSellerMarketplaceClick = () => {
//     navigate('/sellers-marketplace'); // Update to the correct path
//   };

//   const handleEnterHomeAddressClick = () => {
//     navigate('/home-estimate'); // Update to the correct path
//   };

//   return (
//     <div className="sell-page">
//       <div className="selling-options">
//         <div className="option">
//           <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-agent-home-sale.svg' alt="get start" />
//           <h2>RealChoice<sup>TM</sup> Selling</h2>
//           <p>Pick the right agent for you. Answer a few questions and get a list of top agents in your area. Compare their costs and services, and choose the right agent for you.</p>
//           <button className="btn" onClick={handleRealChoiceClick}>Get Started</button>
//         </div>
//         <div className="option">
//           <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-instant-offers.svg' alt="mark" />
//           <h2>Seller's Marketplace</h2>
//           <p>Get offers for your home. Visit Seller’s Marketplace to find out how you can sell without listing or stay in your home while you finance the purchase of your next one.</p>
//           <button className="btn" onClick={handleSellerMarketplaceClick}>Explore Offers</button>
//         </div>
//         <div className="option">
//           <img src='https://static.rdc.moveaws.com/rdc-ui/pictos/picto-couple-couch-laptop.svg' alt="mark" />
//           <h2>RealEstimate<sup>TM</sup></h2>
//           <p>Track your home value. See your RealEstimate<sup>℠</sup> valuation information over time compared to homes in your area.</p>
//           <button className="btn" onClick={handleEnterHomeAddressClick}>Enter home address</button>
//         </div>
//       </div>
//       <h1>Sell Your Property</h1>
//       <form className="property-form" onSubmit={handleSubmit}>
//         <label>
//           Seller Name:
//           <input type="text" name="sellerName" value={propertyDetails.sellerName} onChange={handleChange} required />
//         </label>
//         <label>
//           Phone Number:
//           <input type="text" name="phoneNumber" value={propertyDetails.phoneNumber} onChange={handleChange} required />
//         </label>
//         <label>
//           Property Address:
//           <input type="text" name="propertyAddress" value={propertyDetails.propertyAddress} onChange={handleChange} required />
//         </label>
//         <label>
//           Property Description:
//           <textarea name="propertyDescription" value={propertyDetails.propertyDescription} onChange={handleChange} required />
//         </label>
//         <label>
//           Property Image:
//           <input type="file" name="propertyImage" onChange={handleChange} required />
//         </label>
//         <label>
//           Documents:
//           <input type="file" name="documents" onChange={handleChange} required />
//         </label>
//         <button type="submit" className="btn">Submit</button>
//       </form>
//       {successMessage && <p className="success-message">{successMessage}</p>}
//       {errorMessage && <p className="error-message">{errorMessage}</p>}
//     </div>
//   );
// };

// export default SellPage;
