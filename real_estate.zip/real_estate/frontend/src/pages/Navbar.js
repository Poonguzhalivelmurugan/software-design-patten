import React from 'react';
import { Link } from 'react-router-dom';
import logoImage from '../assets/logo.jpg'; // Adjust the path to your logo image
import { useAuth } from '../context/authcontext';
import './nav.css';

function Navbar() {
  const { isLoggedIn, login, logout } = useAuth();

  const handleLogout = () => {
    localStorage.setItem("role","notloggedin");
    logout();
    // Adjust this according to how you store role information
    // Perform other logout operations if needed
    console.log('role');

  };

  return (
    <nav className="navbar">
      <div className="navbar-logo-title">
        <Link to="/" className="navbar-logo-link">
          <img src={logoImage} alt="Logo" className="navbar-logo" />
          <h1 className="navbar-title">Urban Oasis</h1>
        </Link>
      </div>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li className="dropdown">
          <Link to="" className="dropbtn">Listing</Link>
          <div className="dropdown-content">
            <Link to="/buy">Buy</Link>
            <Link to="/rent">Rent</Link>
            <Link to="/tenant">Tenant</Link>
            <Link to="/property">Property</Link>
            <Link to="/new-construction">New construction</Link>
            <Link to="/coming-soon">Coming soon</Link>
            <Link to="/recent-home-sales">Recent home sales</Link>
            <Link to="/all-homes">All homes</Link>
            <Link to="/resources">Resources</Link>
            <Link to="/home-buying-guide">Home Buying Guide</Link>
            <Link to="/foreclosure-center">Foreclosure center</Link>
            <Link to="/real-estate-app">Real estate app</Link>
            <Link to="/rent-payment">Down payment assistance</Link>
          </div>
        </li>
        <li>
  <Link to="/sell" className="sell-link">
    <i className="fas fa-plus"></i> Add New Property
  </Link>
</li>


        <li className="dropdown">
          <Link to="/" className="dropbtn">Services</Link>
          <div className="dropdown-content">
            <Link to="/agent">Agent</Link>
            <Link to="/maintainance">Maintainance</Link>
            </div>
        </li>
        <li className="dropdown">
          <Link to="/profile" className="dropbtn">
            <i className="fas fa-user"></i> Profile
          </Link>
          <div className="dropdown-content">
            {isLoggedIn ? (
              <>
                <Link to="/my-account">My Account</Link>
                <Link to="/" onClick={handleLogout}>Logout</Link>
              </>
            ) : (
              <>
                <Link to="/login" onClick={login}>Login</Link>
                <Link to="/signup">Sign Up</Link>
              </>
            )}
          </div>
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;
