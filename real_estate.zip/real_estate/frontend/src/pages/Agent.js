import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './agent.css';

const API_URL = 'http://localhost:8080/api/agents';
const agents = [
  {
    id: 1,
    name: "Gopala Krishna Bollam",
    company: "Skyscrapers Construction",
    location: "Hyderabad",
    experience: "5 Years Experience",
    languages: "English, Hindi",
    listings: 21,
  },
  {
    id: 2,
    name: "Gaurav Sood",
    location: "Panchkula",
    listings: 208,
  },
  // Add more agents as needed
];

const AgentCard = ({ agent, onWhatsAppClick, onBookClick }) => (
  <div className="agent-card">
    <div className="agent-img">
      <div className="agent-initial">{agent.name[0]}</div>
    </div>
    <div className="agent-content">
      <h6>{agent.name}</h6>
      {agent.company && <p>{agent.company}</p>}
      <p>{agent.location}</p>
      {agent.experience && (
        <p>
          <i className="fa fa-briefcase"></i> {agent.experience}
        </p>
      )}
      {agent.languages && (
        <p>
          <i className="fa fa-language"></i> {agent.languages}
        </p>
      )}
      <p>{agent.listings} Listings</p>
      <div className="agent-actions">
        <button className="whatsapp-btn" onClick={() => onWhatsAppClick(agent)}>
          WhatsApp
        </button>
        <button className="appointment-btn" onClick={onBookClick}>
          Book an Appointment
        </button>
      </div>
    </div>
  </div>
);

const AgentPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const navigate = useNavigate();

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleWhatsAppClick = (agent) => {
    setSelectedAgent(agent);
    setIsModalOpen(true);
  };

  const handleBookClick = () => {
    navigate('/src/components/book.js'); // Change the path to the correct one for your booking page
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setSelectedAgent(null);
  };

  const filteredAgents = agents.filter(agent => {
    return agent.name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="agent-page">
      <div className="search-bar10">
        <div className="container0">
          <input
            type="text"
            placeholder="Search Agents..."
            value={searchTerm}
            onChange={handleSearch}
            className="search-inputbut"
          />
        </div>
      </div>
      <div className="listing-section1">
        <div className="container">
          <div className="agent-container">
            {filteredAgents.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                onWhatsAppClick={handleWhatsAppClick}
                onBookClick={handleBookClick}
              />
            ))}
          </div>
        </div>
      </div>
      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close-btn" onClick={handleModalClose}>&times;</span>
            <h2>Contact {selectedAgent.name}</h2>
            <form>
              <div className="form-group">
                <label htmlFor="name">Your Name:</label>
                <input type="text" id="name" name="name" required />
              </div>
              <div className="form-group">
                <label htmlFor="email">Your Email:</label>
                <input type="email" id="email" name="email" required />
              </div>
              <div className="form-group">
                <label htmlFor="message">Message:</label>
                <textarea id="message" name="message" required></textarea>
              </div>
              <button type="submit" className="submit-btn">Send Message</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgentPage;
// import React, { useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import './agent.css';

// // API URL for fetching agents
// const API_URL = 'http://localhost:8080/api/agents';

// // Component for displaying individual agent card
// const AgentCard = ({ agent, onWhatsAppClick, onBookClick }) => (
//   <div className="agent-card">
//     <div className="agent-img">
//       <div className="agent-initial">{agent.name[0]}</div>
//     </div>
//     <div className="agent-content">
//       <h6>{agent.name}</h6>
//       {agent.company && <p>{agent.company}</p>}
//       <p>{agent.location}</p>
//       {agent.experience && (
//         <p>
//           <i className="fa fa-briefcase"></i> {agent.experience}
//         </p>
//       )}
//       {agent.languages && (
//         <p>
//           <i className="fa fa-language"></i> {agent.languages}
//         </p>
//       )}
//       <p>{agent.listings} Listings</p>
//       <div className="agent-actions">
//         <button className="whatsapp-btn" onClick={() => onWhatsAppClick(agent)}>
//           WhatsApp
//         </button>
//         <button className="appointment-btn" onClick={onBookClick}>
//           Book an Appointment
//         </button>
//       </div>
//     </div>
//   </div>
// );

// // Main AgentPage component
// const AgentPage = () => {
//   const [agents, setAgents] = useState([]);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedAgent, setSelectedAgent] = useState(null);
//   const [isModalOpen, setIsModalOpen] = useState(false);

//   const navigate = useNavigate();

//   // Fetch agents from the backend
//   useEffect(() => {
//     axios.get(API_URL)
//       .then(response => {
//         setAgents(response.data); // Update state with fetched agents
//       })
//       .catch(error => {
//         console.error("There was an error fetching the agents!", error);
//         // Optional: use static data as a fallback
//         setAgents([
//           {
//             id: 1,
//             name: "Gopala Krishna Bollam",
//             company: "Skyscrapers Construction",
//             location: "Hyderabad",
//             experience: "5 Years Experience",
//             languages: "English, Hindi",
//             listings: 21,
//           },
//           {
//             id: 2,
//             name: "Gaurav Sood",
//             location: "Panchkula",
//             listings: 208,
//           },
//           // Add more static agents as needed
//         ]);
//       });
//   }, []);

//   const handleSearch = (e) => {
//     setSearchTerm(e.target.value);
//   };

//   const handleWhatsAppClick = (agent) => {
//     setSelectedAgent(agent);
//     setIsModalOpen(true);
//   };

//   const handleBookClick = () => {
//     navigate('/src/components/book.js'); // Change the path to the correct one for your booking page
//   };

//   const handleModalClose = () => {
//     setIsModalOpen(false);
//     setSelectedAgent(null);
//   };

//   const filteredAgents = agents.filter(agent => {
//     return agent.name.toLowerCase().includes(searchTerm.toLowerCase());
//   });

//   return (
//     <div className="agent-page">
//       <div className="search-bar10">
//         <div className="container0">
//           <input
//             type="text"
//             placeholder="Search Agents..."
//             value={searchTerm}
//             onChange={handleSearch}
//             className="search-input"
//           />
//         </div>
//       </div>
//       <div className="listing-section1">
//         <div className="container">
//           <div className="agent-container">
//             {filteredAgents.map(agent => (
//               <AgentCard
//                 key={agent.id}
//                 agent={agent}
//                 onWhatsAppClick={handleWhatsAppClick}
//                 onBookClick={handleBookClick}
//               />
//             ))}
//           </div>
//         </div>
//       </div>
//       {isModalOpen && (
//         <div className="modal">
//           <div className="modal-content">
//             <span className="close-btn" onClick={handleModalClose}>&times;</span>
//             <h2>Contact {selectedAgent.name}</h2>
//             <form>
//               <div className="form-group">
//                 <label htmlFor="name">Your Name:</label>
//                 <input type="text" id="name" name="name" required />
//               </div>
//               <div className="form-group">
//                 <label htmlFor="email">Your Email:</label>
//                 <input type="email" id="email" name="email" required />
//               </div>
//               <div className="form-group">
//                 <label htmlFor="message">Message:</label>
//                 <textarea id="message" name="message" required></textarea>
//               </div>
//               <button type="submit" className="submit-btn">Send Message</button>
//             </form>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default AgentPage;

