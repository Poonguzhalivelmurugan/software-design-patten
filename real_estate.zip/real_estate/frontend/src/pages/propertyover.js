import React from 'react';
import { FaRupeeSign, FaRulerCombined, FaBuilding, FaBed, FaMapMarkerAlt, FaCompass, FaEye, FaHammer } from 'react-icons/fa';
import './propertyover.css'; // Make sure to link your CSS file

function PropertyOverview() {
  return (
    <div className="property-overview-container">
      <div className="top-section">
        <div className="image-container">
          <img src="https://imagecdn.99acres.com/media1/24887/10/497750369O-1718169099242.jpg" alt="Property" className="property-image" />
          <div className="image-overlay">
            <span>Photos (1/5)</span>
          </div>
        </div>

        <div className="details-container">
          <div className="info-item">
            <FaRulerCombined className="icon" />
            <span className="info-label">Area</span>
            <span className="info-value">Plot area 1000 <a href="#">sq.ft.</a> (92.9 sq.m.)</span>
          </div>
          <div className="info-item">
            <FaBed className="icon" />
            <span className="info-label">Configuration</span>
            <span className="info-value">2 Bedrooms, 3 Bathrooms, 1 Balcony</span>
          </div>
          <div className="info-item">
            <FaRupeeSign className="icon" />
            <span className="info-label">Price</span>
            <span className="info-value">₹ 52 Lac @ 5,000 per sq.ft. (Negotiable)</span>
          </div>
          <div className="info-item">
            <FaMapMarkerAlt className="icon" />
            <span className="info-label">Address</span>
            <span className="info-value">Irugur House Irugur, Irugur, Coimbatore</span>
          </div>
          <div className="info-item">
            <FaBuilding className="icon" />
            <span className="info-label">Total Floors</span>
            <span className="info-value">1 Floor</span>
          </div>
          <div className="info-item">
            <FaCompass className="icon" />
            <span className="info-label">Facing</span>
            <span className="info-value">North</span>
          </div>
          <div className="info-item">
            <FaEye className="icon" />
            <span className="info-label">Overlooking</span>
            <span className="info-value">Others</span>
          </div>
          <div className="info-item">
            <FaHammer className="icon" />
            <span className="info-label">Property Age</span>
            <span className="info-value">Under Construction</span>
          </div>
        </div>
      </div>

      <div className="bottom-section">
        <div className="owner-section">
          <h3>Owner Details</h3>
          <div className="owner-card">
            <img
              className="owner-photo"
              src="https://static.99acres.com/images/owner_pnava.png"
              alt="Owner"
            />
            <div className="owner-info">
              <div className="owner-name">Subramanian</div>
              <div className="owner-role">Owner</div>
              <button className="view-phone-button">View Phone Number</button>
            </div>
          </div>
          <div className="owner-localities">
            <span>Properties Listed: </span>1
          </div>
          <div className="owner-localities">
            <span>Localities: </span>Irugur
          </div>
        </div>

        <div className="enquiry-section">
          <h3>Send Enquiry to Owner</h3>
          <form className="enquiry-form">
            <div className="radio-group">
              <label>Type:</label>
              <div className="radio-item">
                <input type="radio" id="individual" name="type" value="Individual" />
                <label htmlFor="individual">Individual</label>
              </div>
              <div className="radio-item">
                <input type="radio" id="dealer" name="type" value="Dealer" />
                <label htmlFor="dealer">Dealer</label>
              </div>
            </div>
            <div className="radio-group">
              <label>Reason:</label>
              <div className="radio-item">
                <input type="radio" id="investment" name="reason" value="Investment" />
                <label htmlFor="investment">Investment</label>
              </div>
              <div className="radio-item">
                <input type="radio" id="selfUse" name="reason" value="SelfUse" />
                <label htmlFor="selfUse">Self Use</label>
              </div>
            </div>
            <div className="form-group">
              <input
                type="text"
                name="name"
                placeholder="Name"
                required
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="phone"
                placeholder="Phone"
                required
              />
            </div>
            <div className="form-group">
              <input
                type="email"
                name="email"
                placeholder="Email"
                required
              />
            </div>
            <div className="form-group">
              <textarea
                name="message"
                placeholder="Message"
                rows="4"
                required
              ></textarea>
            </div>
            <button type="submit" className="submit-button">Submit</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default PropertyOverview;