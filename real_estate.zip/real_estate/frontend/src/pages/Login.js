import axios from 'axios'; // Import axios for API calls
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import realEstateImage from '../assets/real-estate.jpg';
import { login } from '../redux/userSlice'; // Import login action
import './login.css'; // Import CSS for styling

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ email: '', password: '' });
  const isAuthenticated = useSelector(state => state.user.isAuthenticated);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');  // Redirect to home page if already authenticated
    }
  }, [isAuthenticated, navigate]);

  const validate = () => {
    let emailError = '';
    let passwordError = '';
    if (!email.includes('@')) emailError = 'Invalid email address';
    if (password.length < 6) passwordError = 'Password must be at least 6 characters';
    if (emailError || passwordError) {
      setErrors({ email: emailError, password: passwordError });
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validate();
    if (isValid) {
      try {
        const response = await axios.post("http://localhost:8080/api/auth/authenticate", {
          email: email,
          password: password,
        });

        if (response.status === 200) {
          const { token, role } = response.data;
          localStorage.setItem("token", token);  // Save token in localStorage
          localStorage.setItem("role", role);    // Save role in localStorage
          console.log(role);
          // Dispatch login action
          dispatch(login({ email, role }));

          // Redirect based on the user's role
          if (role === "Admin") {
            navigate("/admin");
          } else {
            navigate('/');
          }
        } else {
          setErrors({ email: 'Invalid credentials' });
        }
      } catch (error) {
        console.error('Login failed:', error);
        setErrors({ email: 'Login failed. Please check your credentials and try again.' });
      }
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-image">
          <img src={realEstateImage} alt="Real Estate" />
        </div>
        <div className="login-form">
          <h1>Login</h1>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
              {errors.email && <div className="error">{errors.email}</div>}
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
              />
              {errors.password && <div className="error">{errors.password}</div>}
            </div>
            <button type="submit" className="btn">Login</button>
          </form>
          <p>
            Don't have an account? <Link to="/signup">Sign Up</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;// import axios from 'axios'; // Import axios for API calls
// import React, { useEffect, useState } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { Link, useNavigate } from 'react-router-dom';
// import realEstateImage from '../assets/real-estate.jpg';
// import { login } from '../redux/userSlice'; // Import login action
// import './login.css'; // Import CSS for styling

// function LoginPage() {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [errors, setErrors] = useState({ email: '', password: '' });
//   const isAuthenticated = useSelector(state => state.user.isAuthenticated);
//   const dispatch = useDispatch();
//   const navigate = useNavigate();

//   useEffect(() => {
//     if (isAuthenticated) {
//       navigate('/');  // Redirect to home page if already authenticated
//     }
//   }, [isAuthenticated, navigate]);

//   const validate = () => {
//     let emailError = '';
//     let passwordError = '';
//     if (!email.includes('@')) emailError = 'Invalid email address';
//     if (password.length < 6) passwordError = 'Password must be at least 6 characters';
//     if (emailError || passwordError) {
//       setErrors({ email: emailError, password: passwordError });
//       return false;
//     }
//     return true;
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const isValid = validate();
//     if (isValid) {
//       try {
//         const response = await axios.post("http://localhost:8080/api/auth/authenticate", {
//           email: email,
//           password: password,
//         });

//         if (response.status === 200) {
//           const { token, role } = response.data;
//           localStorage.setItem("token", token);  // Save token in localStorage
//           localStorage.setItem("role", role);    // Save role in localStorage

//           // Dispatch login action
//           dispatch(login({ email, role }));

//           // Redirect based on the user's role
//           if (role === "Admin") {
//             navigate("/admin");
//           } else {
//             navigate('/');
//           }
//         } else {
//           setErrors({ email: 'Invalid credentials' });
//         }
//       } catch (error) {
//         console.error('Login failed:', error);
//         setErrors({ email: 'Login failed. Please check your credentials and try again.' });
//       }
//     }
//   };

//   return (
//     <div className="login-page">
//       <div className="login-container">
//         <div className="login-image">
//           <img src={realEstateImage} alt="Real Estate" />
//         </div>
//         <div className="login-form">
//           <h1>Login</h1>
//           <form onSubmit={handleSubmit}>
//             <div className="form-group">
//               <label>Email</label>
//               <input
//                 type="email"
//                 value={email}
//                 onChange={(e) => setEmail(e.target.value)}
//                 placeholder="Enter your email"
//                 required
//               />
//               {errors.email && <div className="error">{errors.email}</div>}
//             </div>
//             <div className="form-group">
//               <label>Password</label>
//               <input
//                 type="password"
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//                 placeholder="Enter your password"
//                 required
//               />
//               {errors.password && <div className="error">{errors.password}</div>}
//             </div>
//             <button type="submit" className="btn">Login</button>
//           </form>
//           <p>
//             Don't have an account? <Link to="/signup">Sign Up</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default LoginPage;

// // // import React, { useState, useEffect } from 'react';
// // // import { useDispatch, useSelector } from 'react-redux';
// // // import { Link, useNavigate } from 'react-router-dom';
// // // import realEstateImage from '../assets/real-estate.jpg';
// // // import { login } from '../redux/userSlice';
// // // import './login.css';

// // // function LoginPage() {
// // //   const [email, setEmail] = useState('');
// // //   const [password, setPassword] = useState('');
// // //   const isAuthenticated = useSelector(state => state.user.isAuthenticated);
// // //   const dispatch = useDispatch();
// // //   const navigate = useNavigate();

// // //   useEffect(() => {
// // //     if (isAuthenticated) {
// // //       navigate('/');  // Redirect to home page if already authenticated
// // //     }
// // //   }, [isAuthenticated, navigate]);

// // //   const handleSubmit = (e) => {
// // //     e.preventDefault();
    
// // //     // Hardcoded credentials for demo purposes
// // //     const adminEmail = 'admin@example.com';
// // //     const adminPassword = 'admin123';
// // //     const userEmail = 'user@example.com';
// // //     const userPassword = 'user123';

// // //     if (email === adminEmail && password === adminPassword) {
// // //       dispatch(login({ email, role: 'admin' }));
// // //       navigate('/admin');  // Redirect to admin page after successful login
// // //     } else if (email === userEmail && password === userPassword) {
// // //       dispatch(login({ email, role: 'user' }));
// // //       navigate('/');  // Redirect to home page after successful login
// // //     } else {
// // //       alert('Invalid credentials');
// // //       navigate('/signup');  // Redirect to signup page if login fails
// // //     }
// // //   };

// // //   return (
// // //     <div className="container">
// // //       <div className="login-container">
// // //         <div className="login-image">
// // //           <img src={realEstateImage} alt="Real Estate" />
// // //         </div>
// // //         <div className="login-form">
// // //           <h1>Login</h1>
// // //           <form onSubmit={handleSubmit}>
// // //             <div className="form-group">
// // //               <label>Email</label>
// // //               <input
// // //                 type="email"
// // //                 value={email}
// // //                 onChange={(e) => setEmail(e.target.value)}
// // //                 placeholder="Enter your email"
// // //                 required
// // //               />
// // //             </div>
// // //             <div className="form-group">
// // //               <label>Password</label>
// // //               <input
// // //                 type="password"
// // //                 value={password}
// // //                 onChange={(e) => setPassword(e.target.value)}
// // //                 placeholder="Enter your password"
// // //                 required
// // //               />
// // //             </div>
// // //             <button type="submit" className="btn">Login</button>
// // //           </form>
// // //           <p>
// // //             Don't have an account? <Link to="/signup">Sign Up</Link>
// // //           </p>
// // //         </div>
// // //       </div>
// // //     </div>
// // //   );
// // // }

// // // export default LoginPage;
// // import React, { useState, useEffect } from 'react';
// // import { useDispatch, useSelector } from 'react-redux';
// // import { Link, useNavigate } from 'react-router-dom';
// // import axios from 'axios'; // Import axios for API calls
// // import realEstateImage from '../assets/real-estate.jpg';
// // import { login } from '../redux/userSlice';
// // import './login.css';

// // function LoginPage() {
// //   const [email, setEmail] = useState('');
// //   const [password, setPassword] = useState('');
// //   const isAuthenticated = useSelector(state => state.user.isAuthenticated);
// //   const dispatch = useDispatch();
// //   const navigate = useNavigate();

// //   useEffect(() => {
// //     if (isAuthenticated) {
// //       navigate('/');  // Redirect to home page if already authenticated
// //     }
// //   }, [isAuthenticated, navigate]);

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();

// //     try {
// //       const response = await axios.post("http://localhost:8080/api/auth/authenticate", {
// //         email: email,
// //         password: password,
// //       });

// //       // Check if the login was successful
// //       if (response.status === 200) {
// //         const { token, role } = response.data;

// //         // Save token and role in localStorage (optional but recommended for session management)
// //         localStorage.setItem("token", token);
// //         localStorage.setItem("role", role);

// //         // Dispatch login action to store user state
// //         dispatch(login({ email, role }));

// //         // Redirect based on the user's role
// //         if (role === "ROLE_ADMIN") {
// //           navigate("/admin");
// //         } else {
// //           navigate('/');
// //         }
// //       } else {
// //         alert('Invalid credentials');
// //       }
// //     } catch (error) {
// //       console.error('Login failed:', error);
// //       alert('Login failed. Please check your credentials and try again.');
// //     }
// //   };

// //   return (
// //     // <div className="login-page">
// //       <div className="login-container">
// //         <div className="login-image">
// //           <img src={realEstateImage} alt="Real Estate" />
// //         </div>
// //         <div className="login-form">
// //           <h1>Login</h1>
// //           <form onSubmit={handleSubmit}>
// //             <div className="form-group">
// //               <label>Email</label>
// //               <input
// //                 type="email"
// //                 value={email}
// //                 onChange={(e) => setEmail(e.target.value)}
// //                 placeholder="Enter your email"
// //                 required
// //               />
// //             </div>
// //             <div className="form-group">
// //               <label>Password</label>
// //               <input
// //                 type="password"
// //                 value={password}
// //                 onChange={(e) => setPassword(e.target.value)}
// //                 placeholder="Enter your password"
// //                 required
// //               />
// //             </div>
// //             <button type="submit" className="btn">Login</button>
// //           </form>
// //           <p>
// //             Don't have an account? <Link to="/signup">Sign Up</Link>
// //           </p>
// //         </div>
// //       </div>
// //     // </div>
// //   );
// // }

// // export default LoginPage;
